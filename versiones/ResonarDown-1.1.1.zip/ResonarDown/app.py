"""ResonarDown: descarga música y video en la mejor calidad disponible.
© 2026 VCARD26.

Inicia el servidor local y abre la ventana de la aplicación.
Uso:  python app.py            (ventana de escritorio)
      python app.py --browser  (abre en el navegador)
"""
import os
import sys
import threading
import time
import traceback
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

AUMID = "VCARD26.ResonarDown"
ICON = ROOT / "resonar.ico"

# Herramientas instaladas junto a Python (deno) y por winget (ffmpeg) visibles para yt-dlp.
_bin = [str(Path(sys.executable).parent), str(ROOT / "bin")]
if sys.platform == "win32" and os.environ.get("LOCALAPPDATA"):
    _bin.append(str(Path(os.environ["LOCALAPPDATA"]) / "Microsoft" / "WinGet" / "Links"))
os.environ["PATH"] = os.pathsep.join(_bin + [os.environ.get("PATH", "")])

from core import store  # noqa: E402  (liviano; el motor se carga después de abrir la ventana)

# Todo lo que generan las herramientas queda dentro de la carpeta de datos de ResonarDown.
os.environ["DENO_DIR"] = str(store.DATA / "deno")
os.environ.setdefault("TORCH_HOME", str(store.DATA / "torch"))
os.environ.setdefault("NUMBA_CACHE_DIR", str(store.DATA / "cache" / "numba"))
LOG = store.DATA / "resonar.log"


def windows_identity():
    """Hace que Windows agrupe la ventana como ResonarDown y no como Python."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(AUMID)
    except Exception:
        traceback.print_exc()


def set_window_icon(title="ResonarDown"):
    """Pone el ícono de ResonarDown en la ventana y en la barra de tareas."""
    if sys.platform != "win32" or not ICON.exists():
        return
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        u.LoadImageW.restype = wintypes.HANDLE
        u.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        u.SendMessageW.restype = ctypes.c_ssize_t
        u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.IsWindowVisible.argtypes = [wintypes.HWND]
        u.SetClassLongPtrW.restype = ctypes.c_ssize_t
        u.SetClassLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
        pid = os.getpid()
        found = []
        PROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(hwnd, _):
            owner = wintypes.DWORD()
            u.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            if owner.value == pid and u.IsWindowVisible(hwnd):
                buf = ctypes.create_unicode_buffer(256)
                u.GetWindowTextW(hwnd, buf, 256)
                if buf.value == title:
                    found.append(hwnd)
            return True

        cb_ref = PROC(cb)
        for _ in range(100):
            u.EnumWindows(cb_ref, 0)
            if found:
                break
            time.sleep(0.1)
        if not found:
            return
        hwnd = found[0]
        big = u.LoadImageW(None, str(ICON), 1, 64, 64, 0x10)
        small = u.LoadImageW(None, str(ICON), 1, u.GetSystemMetrics(49), u.GetSystemMetrics(50), 0x10)
        if big:
            u.SendMessageW(hwnd, 0x0080, 1, big)        # WM_SETICON, ICON_BIG
            u.SetClassLongPtrW(hwnd, -14, big)         # GCLP_HICON
        if small:
            u.SendMessageW(hwnd, 0x0080, 0, small)      # WM_SETICON, ICON_SMALL
            u.SetClassLongPtrW(hwnd, -34, small)       # GCLP_HICONSM
    except Exception:
        traceback.print_exc()


SPLASH = """<!doctype html><html lang="es"><head><meta charset="utf-8"><style>
html,body{margin:0;height:100%;background:#0b0e1c;color:#eef0fb;font:15px "Segoe UI",system-ui,sans-serif}
body{display:grid;place-items:center}
.b{display:flex;flex-direction:column;align-items:center;gap:16px}
.l{width:64px;height:64px;animation:p 1.4s ease-in-out infinite}
p{margin:0;color:#9aa1c0}
@keyframes p{50%{transform:scale(.92);opacity:.8}}
@media (prefers-reduced-motion:reduce){.l{animation:none}}
</style></head><body><div class="b"><svg class="l" viewBox="0 0 64 64"><rect width="64" height="64" rx="15" fill="#0B5FFF"/><circle cx="32" cy="32" r="22" fill="#fff"/><circle cx="32" cy="32" r="17" fill="none" stroke="#0B5FFF" stroke-width="1.3" opacity=".55"/><circle cx="32" cy="32" r="12.5" fill="none" stroke="#0B5FFF" stroke-width="1.3" opacity=".55"/><circle cx="32" cy="32" r="8.5" fill="#0B5FFF"/><path d="M32 26.5V36M28 32.5l4 4 4-4" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg><p>Abriendo ResonarDown…</p></div></body></html>"""


class Api:
    """Funciones que la interfaz puede llamar desde la ventana de escritorio.

    La ventana se guarda en un atributo privado (_window): pywebview recorre todo
    lo público de este objeto al cargar la página, y recorrer la ventana de Windows
    por dentro congelaba la aplicación varios segundos.
    """

    def __init__(self):
        self._window = None

    def choose_folder(self):
        import webview
        kind = getattr(getattr(webview, "FileDialog", None), "FOLDER", None) or getattr(webview, "FOLDER_DIALOG", 20)
        res = self._window.create_file_dialog(kind, directory=store.get_settings()["download_dir"])
        if res:
            return res[0] if isinstance(res, (list, tuple)) else res
        return None


def start_backend():
    """Carga el motor de descargas y el servidor local. Devuelve la dirección de la app."""
    from core import engine, server, updater
    updater.clean_leftovers()
    engine.ensure_ffmpeg()
    srv = server.start(0)
    url = f"http://127.0.0.1:{srv.server_address[1]}/"
    print(time.strftime("%Y-%m-%d %H:%M:%S"), "ResonarDown", store.APP_VERSION, "iniciado en", url, flush=True)
    return url


def main():
    # Guarda errores en un archivo, ya que la ventana se abre sin consola.
    if sys.stdout is None or "pythonw" in Path(sys.executable).name.lower():
        try:
            if LOG.exists() and LOG.stat().st_size > 1024 * 1024:   # el registro no crece sin límite
                os.replace(LOG, LOG.with_suffix(".log.1"))
        except OSError:
            pass
        f = open(LOG, "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = f
    windows_identity()

    if "--browser" not in sys.argv:
        try:
            import webview
        except Exception:
            traceback.print_exc()
            webview = None
        if webview:
            # La ventana aparece al instante con una pantalla de carga; el motor arranca aparte.
            api = Api()
            win = webview.create_window("ResonarDown", html=SPLASH, width=1220, height=860, min_size=(420, 620),
                                        js_api=api, background_color="#0b0e1c", text_select=True)
            api._window = win
            win.events.shown += lambda: threading.Thread(target=set_window_icon, daemon=True).start()

            def boot():
                try:
                    win.load_url(start_backend())
                except Exception:
                    traceback.print_exc()
                    win.load_html(SPLASH.replace("Abriendo ResonarDown…", "No se pudo iniciar ResonarDown. Revisa %APPDATA%\\ResonarDown\\resonar.log"))

            webview.start(boot, private_mode=False, storage_path=str(store.DATA / "webview"), icon=str(ICON))
            return

    url = start_backend()
    webbrowser.open(url)
    print("ResonarDown está abierto en tu navegador. Cierra esta ventana para salir.", flush=True)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
