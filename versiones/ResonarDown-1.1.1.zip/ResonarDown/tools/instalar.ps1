﻿# ResonarDown: accesos directos y registro en "Aplicaciones" de Windows.
# © 2026 VCARD26.
param(
    [string]$AppDir,
    [int]$InstalledPython = 0,
    [int]$InstalledFFmpeg = 0
)
$ErrorActionPreference = 'Continue'
$AppDir = [IO.Path]::GetFullPath($AppDir).TrimEnd('\')
$Version = '1.1.1'
$Aumid = 'VCARD26.ResonarDown'
$Pyw = Join-Path $AppDir '.venv\Scripts\pythonw.exe'
$Ico = Join-Path $AppDir 'resonar.ico'

# Permite que el acceso directo y la ventana abierta compartan el mismo ícono en la barra de tareas.
$code = @"
using System;
using System.Runtime.InteropServices;

[ComImport, Guid("00021401-0000-0000-C000-000000000046")]
internal class ResonarDownShellLink { }

[ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("0000010b-0000-0000-C000-000000000046")]
internal interface IResonarDownPersistFile {
    void GetClassID(out Guid pClassID);
    [PreserveSig] int IsDirty();
    void Load([MarshalAs(UnmanagedType.LPWStr)] string pszFileName, uint dwMode);
    void Save([MarshalAs(UnmanagedType.LPWStr)] string pszFileName, [MarshalAs(UnmanagedType.Bool)] bool fRemember);
    void SaveCompleted([MarshalAs(UnmanagedType.LPWStr)] string pszFileName);
    void GetCurFile([MarshalAs(UnmanagedType.LPWStr)] out string ppszFileName);
}

[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct ResonarDownPropKey { public Guid fmtid; public uint pid; }

[StructLayout(LayoutKind.Explicit)]
public struct ResonarDownPropVariant {
    [FieldOffset(0)] public ushort vt;
    [FieldOffset(8)] public IntPtr p;
    [FieldOffset(16)] public IntPtr pad;
}

[ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")]
internal interface IResonarDownPropertyStore {
    [PreserveSig] int GetCount(out uint cProps);
    [PreserveSig] int GetAt(uint iProp, out ResonarDownPropKey pkey);
    [PreserveSig] int GetValue(ref ResonarDownPropKey key, out ResonarDownPropVariant pv);
    [PreserveSig] int SetValue(ref ResonarDownPropKey key, ref ResonarDownPropVariant pv);
    [PreserveSig] int Commit();
}

public static class ResonarDownAumid {
    public static void Set(string lnk, string id) {
        object link = new ResonarDownShellLink();
        IResonarDownPersistFile pf = (IResonarDownPersistFile)link;
        pf.Load(lnk, 2);
        IResonarDownPropertyStore ps = (IResonarDownPropertyStore)link;
        ResonarDownPropKey key = new ResonarDownPropKey();
        key.fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");
        key.pid = 5;
        ResonarDownPropVariant v = new ResonarDownPropVariant();
        v.vt = 31;
        v.p = Marshal.StringToCoTaskMemUni(id);
        try {
            int hr = ps.SetValue(ref key, ref v);
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            hr = ps.Commit();
            if (hr != 0) Marshal.ThrowExceptionForHR(hr);
            pf.Save(lnk, true);
        } finally {
            Marshal.FreeCoTaskMem(v.p);
            Marshal.ReleaseComObject(link);
        }
    }
}
"@
$canAumid = $false
try { Add-Type -TypeDefinition $code -Language CSharp -ErrorAction Stop; $canAumid = $true } catch { }

# ---------- Nombre anterior (Resonar, hasta la 1.0.0) ----------
# Quita los accesos directos viejos y pasa los datos del registro anterior al nuevo.
$oldLinks = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Resonar.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Resonar.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Resonar.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\StartMenu\Resonar.lnk')
)
foreach ($l in $oldLinks) { Remove-Item -LiteralPath $l -Force -ErrorAction SilentlyContinue }
$oldKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Resonar'
$old = Get-ItemProperty -Path $oldKey -ErrorAction SilentlyContinue
if ($old) {
    if ($old.InstalledPython -eq 1) { $InstalledPython = 1 }
    if ($old.InstalledFFmpeg -eq 1) { $InstalledFFmpeg = 1 }
    Remove-Item -Path $oldKey -Recurse -Force -ErrorAction SilentlyContinue
}

# ---------- Accesos directos ----------
$shell = New-Object -ComObject WScript.Shell
$places = @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))
foreach ($dir in $places) {
    if (-not (Test-Path $dir)) { continue }
    $lnk = Join-Path $dir 'ResonarDown.lnk'
    $l = $shell.CreateShortcut($lnk)
    $l.TargetPath = $Pyw
    $l.Arguments = 'app.py'
    $l.WorkingDirectory = $AppDir
    $l.IconLocation = "$Ico,0"
    $l.Description = 'ResonarDown. © 2026 VCARD26'
    $l.Save()
    if ($canAumid) { try { [ResonarDownAumid]::Set($lnk, $Aumid) } catch { } }
}

# ---------- Registro en Configuración > Aplicaciones ----------
$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ResonarDown'
$prev = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
if ($prev) {
    if ($prev.InstalledPython -eq 1) { $InstalledPython = 1 }
    if ($prev.InstalledFFmpeg -eq 1) { $InstalledFFmpeg = 1 }
}
New-Item -Path $key -Force | Out-Null
$sizeKb = [int]((Get-ChildItem $AppDir -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1KB)
$uninstall = '"' + $env:ComSpec + '" /c ""' + (Join-Path $AppDir 'Desinstalar.bat') + '""'
$strings = @{
    DisplayName     = 'ResonarDown'
    DisplayVersion  = $Version
    Publisher       = 'VCARD26'
    DisplayIcon     = $Ico
    InstallLocation = $AppDir
    UninstallString = $uninstall
    Comments        = 'Descarga música y video en la mejor calidad. © 2026 VCARD26'
    InstallDate     = (Get-Date -Format 'yyyyMMdd')
}
foreach ($k in $strings.Keys) { New-ItemProperty -Path $key -Name $k -Value $strings[$k] -PropertyType String -Force | Out-Null }
$dwords = @{ EstimatedSize = $sizeKb; NoModify = 1; NoRepair = 1; InstalledPython = $InstalledPython; InstalledFFmpeg = $InstalledFFmpeg }
foreach ($k in $dwords.Keys) { New-ItemProperty -Path $key -Name $k -Value $dwords[$k] -PropertyType DWord -Force | Out-Null }
# Pide a Windows que refresque su caché de íconos (para que se vea el ícono nuevo al actualizar).
try { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\ie4uinit.exe') -ArgumentList '-show' -WindowStyle Hidden -ErrorAction Stop } catch { }
Write-Host '  Accesos directos y registro listos.'
