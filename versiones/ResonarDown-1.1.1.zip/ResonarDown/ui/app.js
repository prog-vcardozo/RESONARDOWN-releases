/* ResonarDown: interfaz. © 2026 VCARD26. */
var TOKEN=(document.querySelector('meta[name="rd-token"]')||{}).content||'';
var D=['#0B5FFF','#1E6BFF'];
var PL={
 youtube:{n:'YouTube',d:'#ff5148',d2:'#ff9b54'},
 spotify:{n:'Spotify',d:'#24d869',d2:'#13b6b0'},
 tiktok:{n:'TikTok',d:'#27d9d4',d2:'#ff3d6e'},
 instagram:{n:'Instagram',d:'#f0457f',d2:'#fdb347'},
 soundcloud:{n:'SoundCloud',d:'#ff6a1a',d2:'#ffb04a'},
 otro:{n:'Web',d:'#0B5FFF',d2:'#1E6BFF'}
};
var RE={youtube:/youtube\.com|youtu\.be/i,spotify:/open\.spotify\.com|spotify\.link/i,tiktok:/tiktok\.com/i,instagram:/instagram\.com/i,soundcloud:/soundcloud\.com/i};
var $=function(i){return document.getElementById(i)},R=document.documentElement;
var info=null,mode='orig',sel=0,matchSel=0,busy=0,ENG={},SET={},LIB=[],JOBS=[],REQS={},GREQS={},OPEN={},PSEL=[],pollT=null;
var DONE_ST={done:1,error:1,cancelled:1};

/* ---------- utilidades ---------- */
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function hash(s){var h=0;for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h}
function mmss(d){d=Math.round(d||0);var h=Math.floor(d/3600),m=Math.floor(d%3600/60),s=('0'+d%60).slice(-2);return h?h+':'+('0'+m).slice(-2)+':'+s:m+':'+s}
function mb(kbps,d){return (kbps*d/8/1024).toFixed(1).replace('.',',')+' MB'}
function api(path,body){
 var o={headers:{'X-ResonarDown-Token':TOKEN}};
 if(body!==undefined){o.method='POST';o.headers['Content-Type']='application/json';o.body=JSON.stringify(body)}
 return fetch(path,o).then(function(r){return r.json().then(function(j){if(!r.ok||j.error)throw new Error(j.error||'Error inesperado');return j})},function(){throw new Error('ResonarDown no responde. Ciérralo y vuelve a abrirlo.')});
}
function img(u){return u?'/api/img?t='+TOKEN+'&u='+encodeURIComponent(u):''}
function toast(t){var el=$('toast');el.textContent=t;el.hidden=false;clearTimeout(el._t);el._t=setTimeout(function(){el.hidden=true},3500)}
function cover(title,artist,c){
 c=c||D;var h=hash((title||'')+(artist||''));
 var base=(artist||title||'?').replace('@','');
 var ini=base.split(/\s+|&/).filter(Boolean).slice(0,2).map(function(w){return w[0]}).join('').toUpperCase();
 var s='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="'+c[0]+'"/><stop offset="1" stop-color="'+c[1]+'"/></linearGradient></defs><rect width="120" height="120" fill="url(#g)"/>'+
  '<circle cx="'+(30+h%60)+'" cy="'+(25+(h>>3)%50)+'" r="'+(26+(h>>5)%22)+'" fill="#ffffff" fill-opacity=".2"/>'+
  '<circle cx="'+(50+(h>>7)%50)+'" cy="'+(55+(h>>9)%40)+'" r="'+(14+(h>>11)%20)+'" fill="#000000" fill-opacity=".16"/>'+
  '<text x="10" y="110" font-family="Arial,sans-serif" font-weight="800" font-size="15" fill="#ffffff">'+esc(ini)+'</text></svg>';
 return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s);
}
function imgTag(src,fb,cls,alt,id){return '<img'+(id?' id="'+id+'"':'')+(cls?' class="'+cls+'"':'')+' alt="'+esc(alt||'')+'" src="'+esc(src||fb)+'" data-fb="'+fb+'">'}
document.addEventListener('error',function(e){var el=e.target;if(el&&el.tagName==='IMG'&&el.dataset.fb&&el.src!==el.dataset.fb)el.src=el.dataset.fb},true);
function lumOf(c){
 var el=document.createElement('i');el.style.color=c;document.body.appendChild(el);
 var m=(getComputedStyle(el).color.match(/[\d.]+/g)||[0,0,0]).slice(0,3).map(Number);el.remove();
 var v=m.map(function(x){x/=255;return x<=.03928?x/12.92:Math.pow((x+.055)/1.055,2.4)});
 return .2126*v[0]+.7152*v[1]+.0722*v[2];
}
/* Elige el texto de los botones (blanco u oscuro) que mejor se lee sobre los dos colores del degradado. */
function paint(c){
 R.style.setProperty('--a1',c[0]);R.style.setProperty('--a2',c[1]);
 var l1=lumOf(c[0]),l2=lumOf(c[1]),DK=.0045;
 var white=Math.min(1.05/(l1+.05),1.05/(l2+.05)),dark=Math.min((l1+.05)/(DK+.05),(l2+.05)/(DK+.05));
 R.style.setProperty('--ink',white>=dark?'#ffffff':'#0a0c1c');
}
function tint(im){
 /* Busca los dos tonos más vivos y distintos de la carátula; si es gris, deja el color de la plataforma. */
 try{
  var N=24,c=document.createElement('canvas');c.width=c.height=N;var g=c.getContext('2d');g.drawImage(im,0,0,N,N);
  var d=g.getImageData(0,0,N,N).data,px=[];
  for(var i=0;i<N*N;i++){
   var r=d[i*4]/255,gg=d[i*4+1]/255,b=d[i*4+2]/255,mx=Math.max(r,gg,b),mn=Math.min(r,gg,b),l=(mx+mn)/2,s=mx===mn?0:(l>.5?(mx-mn)/(2-mx-mn):(mx-mn)/(mx+mn)),h=0;
   if(mx!==mn){h=mx===r?(gg-b)/(mx-mn)+(gg<b?6:0):mx===gg?(b-r)/(mx-mn)+2:(r-gg)/(mx-mn)+4;h*=60}
   if(s>.3&&l>.18&&l<.85)px.push({h:h,s:s,l:l,w:s*(1-Math.abs(l-.5))});
  }
  if(px.length<N*N*.04)return null;
  var bins={};px.forEach(function(p){var k=Math.round(p.h/20)%18;(bins[k]=bins[k]||{w:0,h:0,n:0});bins[k].w+=p.w;bins[k].h+=p.h;bins[k].n++});
  var list=Object.keys(bins).map(function(k){var o=bins[k];return {h:o.h/o.n,w:o.w}}).sort(function(a,b){return b.w-a.w});
  var h1=list[0].h,h2=null;
  for(var j=1;j<list.length;j++){var dd=Math.abs(list[j].h-h1);dd=Math.min(dd,360-dd);if(dd>=35&&list[j].w>list[0].w*.12){h2=list[j].h;break}}
  if(h2===null)h2=(h1+40)%360;
  var cols=['hsl('+Math.round(h1)+',85%,63%)','hsl('+Math.round(h2)+',80%,62%)'];
  paint(cols);return cols;
 }catch(e){return null}
}
function detect(u){for(var k in RE)if(RE[k].test(u))return k;return 'otro'}

/* ---------- plataformas ---------- */
$('plats').innerHTML='<span>Funciona con</span>'+['youtube','spotify','tiktok','instagram','soundcloud'].map(function(k){return '<span class="chip" data-p="'+k+'" style="--d:'+PL[k].d+'">'+PL[k].n+'</span>'}).join('');
function markChip(k){document.querySelectorAll('.chip').forEach(function(s){s.classList.toggle('on',s.dataset.p===k)})}

/* ---------- análisis ---------- */
function skeleton(){
 $('meta').innerHTML='<div class="sk cover"></div><div><div class="sk" style="width:90px;height:12px;margin-bottom:12px"></div><div class="sk" style="width:80%;height:26px;margin-bottom:10px"></div><div class="sk" style="width:45%;height:16px;margin-bottom:14px"></div><div class="sk" style="width:60%;height:20px"></div></div>';
 $('match').hidden=true;$('plist').hidden=true;$('choose').hidden=true;
}
function analyze(asList){
 asList=asList===true;
 var u=$('url').value.trim(),m=$('msg');m.className='msg';
 if(!u){m.textContent='Pega un enlace para empezar.';return}
 if(!/^https?:\/\//i.test(u)){m.className='msg err';m.textContent='Pega un enlace completo que empiece con https://';return}
 var k=detect(u);markChip(k);paint([PL[k].d,PL[k].d2]);
 m.textContent=asList||/[?&]list=|\/playlist\/|\/album\/|\/sets\//.test(u)?'Leyendo la lista completa… puede tardar unos segundos.':(k==='spotify'?'Leyendo datos de Spotify y buscando la canción…':'Leyendo datos de '+PL[k].n+'…');
 $('card').hidden=false;skeleton();$('analyze').disabled=true;
 var my=++busy;
 api('/api/info',{url:u,playlist:asList}).then(function(j){
  if(my!==busy)return;
  info=j;matchSel=0;
  if(j.type==='playlist'){
   PSEL=j.entries.map(function(e){return e.available});
   var nOk=PSEL.filter(Boolean).length;
   m.textContent='Lista leída: '+j.count+' elementos'+(nOk<j.count?', '+(j.count-nOk)+' no disponibles':'')+'. Elige cuáles descargar.';
   fillPlaylist();$('choose').hidden=false;setMode('orig');render();return;
  }
  m.textContent=k==='spotify'?(j.matches&&j.matches.length?'Elige la versión correcta y descarga.':'No encontramos la canción en YouTube.'):'Listo. Elige el formato y descarga.';
  fillMeta();if(j.platform==='spotify')fillMatch();
  $('choose').hidden=k==='spotify'&&!(j.matches&&j.matches.length);
  setMode('orig');render();
 }).catch(function(e){
  if(my!==busy)return;
  $('card').hidden=true;m.className='msg err';m.textContent=e.message;paint(D);
 }).finally(function(){if(my===busy)$('analyze').disabled=false});
}
function fillMeta(){
 var p=info,pl=PL[p.platform]||PL.otro,f=[];
 if(p.album)f.push('<span>Álbum <b>'+esc(p.album)+'</b></span>');
 if(p.year)f.push('<span>Año <b>'+esc(p.year)+'</b></span>');
 if(p.duration)f.push('<span>Duración <b>'+mmss(p.duration)+'</b></span>');
 if(p.channel&&p.channel!==p.artist)f.push('<span>Canal <b>'+esc(p.channel)+'</b></span>');
 var a=p.audio&&p.audio[0];
 if(a&&p.platform!=='spotify')f.push('<span>Mejor audio <b>'+esc(a.codec)+(a.kbps?' '+a.kbps+' kbps':'')+'</b></span>');
 var fb=cover(p.title,p.artist,[pl.d,pl.d2]);
 $('meta').innerHTML=imgTag(img(p.thumbnail),fb,'cover','Carátula de '+p.title,'cv')+
  '<div style="min-width:0"><span class="kind" style="--d:'+pl.d+'">'+pl.n+'</span>'+
  '<p class="ttl" id="tT">'+esc(p.title)+'</p><p class="art" id="tA">'+(esc(p.artist)||'<span style="color:var(--muted);font-weight:500">Artista desconocido</span>')+'</p>'+
  '<div class="facts">'+f.join('')+'</div>'+
  (p.raw_title&&p.raw_title!==p.title?'<p class="raw">Título publicado: '+esc(p.raw_title)+'</p>':'')+
  '<button class="lk" id="editBtn" type="button" style="margin-top:8px">Corregir título o artista</button>'+
  '<div class="edit" id="editBox" hidden><label>Título<input id="eT" value="'+esc(p.title)+'"></label><label>Artista<input id="eA" value="'+esc(p.artist)+'"></label></div>'+
  (p.playlist_hint?'<div class="hint"><span>Este video es parte de una lista de reproducción.</span><button class="btn line sm" id="asList" type="button">Ver la lista completa</button></div>':'')+'</div>';
 var im=$('cv');var go=function(){if(im.src.indexOf('/api/img')>-1)tint(im)};im.addEventListener('load',go);if(im.complete&&im.naturalWidth)go();
 $('editBtn').onclick=function(){var b=$('editBox');b.hidden=!b.hidden};
 if($('asList'))$('asList').onclick=function(){analyze(true)};
 $('eT').oninput=function(){info.title=this.value;$('tT').textContent=this.value};
 $('eA').oninput=function(){info.artist=this.value;$('tA').textContent=this.value};
}
function fillPlaylist(){
 var p=info,pl=PL[p.platform]||PL.otro,f=[];
 var kind=p.platform==='spotify'?(p.collection_kind==='album'?'Álbum de Spotify':'Lista de Spotify'):'Lista de '+pl.n;
 f.push('<span>Elementos <b>'+p.count+'</b></span>');
 if(p.duration)f.push('<span>Duración total <b>'+mmss(p.duration)+'</b></span>');
 var fb=cover(p.title,p.artist,[pl.d,pl.d2]);
 $('meta').innerHTML=imgTag(img(p.thumbnail),fb,'cover','Portada de '+p.title,'cv')+
  '<div style="min-width:0"><span class="kind" style="--d:'+pl.d+'">'+kind+'</span>'+
  '<p class="ttl">'+esc(p.title)+'</p><p class="art">'+(esc(p.artist)||'')+'</p><div class="facts">'+f.join('')+'</div>'+
  (p.platform==='spotify'?'<p class="raw">Cada canción se busca en YouTube al descargarla. Si no hay una coincidencia segura, se marca con error para que la revises.</p>':'')+'</div>';
 var im=$('cv');var go=function(){if(im.src.indexOf('/api/img')>-1)tint(im)};im.addEventListener('load',go);if(im.complete&&im.naturalWidth)go();
 renderPlist();
}
function renderPlist(){
 var p=info,n=PSEL.filter(Boolean).length;
 $('plist').hidden=false;
 $('plist').innerHTML='<div class="plhead"><b id="plCount">'+n+' de '+p.count+' seleccionadas</b><span style="display:flex;gap:12px"><button class="lk" type="button" data-all="1">Todas</button><button class="lk" type="button" data-all="0">Ninguna</button></span></div>'+
  '<div class="pl">'+p.entries.map(function(e,i){
   return '<label class="pli'+(e.available?'':' off')+'"><input type="checkbox" data-i="'+i+'"'+(PSEL[i]?' checked':'')+(e.available?'':' disabled')+'><span class="num">'+e.n+'</span><span class="nm"><b>'+esc(e.title)+'</b><small>'+esc(e.available?(e.artist||''):'No disponible')+'</small></span><span class="dur">'+(e.duration?mmss(e.duration):'')+'</span></label>'}).join('')+'</div>';
}
$('plist').addEventListener('change',function(e){var c=e.target;if(c.dataset.i===undefined)return;PSEL[+c.dataset.i]=c.checked;$('plCount').textContent=PSEL.filter(Boolean).length+' de '+info.count+' seleccionadas';render()});
$('plist').addEventListener('click',function(e){var b=e.target.closest('[data-all]');if(!b)return;var on=b.dataset.all==='1';PSEL=info.entries.map(function(x){return on&&x.available});renderPlist();render()});
function selDur(){return info.entries.reduce(function(a,e,i){return a+(PSEL[i]?e.duration:0)},0)}
function fillMatch(){
 var p=info,ms=p.matches||[];$('match').hidden=false;
 if(!ms.length){$('match').innerHTML='<h3>No encontramos esta canción en YouTube</h3><p style="margin:0">Prueba buscarla en YouTube y pega ese enlace directamente.</p>';return}
 var a=ms[matchSel],diff=p.duration&&a.duration?Math.abs(a.duration-p.duration):null,good=a.score>=85;
 $('match').innerHTML='<h3>De dónde sale el audio</h3>'+
  '<p>Spotify no permite descargar su audio. Encontramos la canción en YouTube; revisa que sea la versión correcta.</p>'+
  '<div class="checks"><div><small>Título y artista</small><span class="'+(good?'ok':'wn')+'">'+(good?'Coinciden':'Revisa la versión')+'</span></div>'+
  '<div><small>Duración</small><span class="'+(diff!==null&&diff<=3?'ok':'wn')+'">'+(diff===null?'Sin dato':mmss(p.duration)+' frente a '+mmss(a.duration))+'</span></div>'+
  '<div><small>Confianza</small><span class="'+(good?'ok':'wn')+'">'+a.score+'%</span></div></div>'+
  '<div class="alts" role="radiogroup" aria-label="Coincidencias encontradas">'+ms.map(function(x,i){
   return '<button type="button" class="alt" role="radio" aria-checked="'+(i===matchSel)+'" data-a="'+i+'"><span>'+esc(x.title)+'<br><small style="color:var(--muted)">'+esc(x.channel)+(x.duration?', '+mmss(x.duration):'')+'</small></span><span class="pc '+(x.score>=85?'ok':'wn')+'">'+x.score+'%</span></button>'}).join('')+'</div>';
}
$('match').onclick=function(e){var b=e.target.closest('.alt');if(b){matchSel=+b.dataset.a;fillMatch()}};

/* ---------- formatos ---------- */
function options(){
 var p=info,o=[];
 if(p.type==='playlist'){
  if(mode==='orig')o.push({l:'Mejor audio disponible',s:p.platform==='spotify'?'Desde YouTube, sin recodificar':'Cada canción en su mejor formato, sin recodificar',fmt:'bestaudio',k:null,best:1,label:'Original'});
  else if(mode==='comp'){
   o.push({l:'MP3 320 kbps',s:'Recodificado, máxima compatibilidad',fmt:'mp3-320',k:320,label:'MP3 320 kbps'});
   o.push({l:'MP3 192 kbps',s:'Recodificado, archivos más livianos',fmt:'mp3-192',k:192,label:'MP3 192 kbps'});
   o.push({l:'M4A AAC 256 kbps',s:'Para Apple y celulares',fmt:'m4a-256',k:256,label:'AAC 256 kbps'});
  }else (p.video||[]).forEach(function(h,i){o.push({l:h+'p MP4',s:i===0?'La mejor calidad hasta 1080p':(h<=480?'Para ahorrar espacio':'Equilibrio de peso y nitidez'),fmt:String(h),v:h>=1080?6:h>=720?3:1.2,best:i===0,label:h+'p MP4'})});
  return o;
 }
 if(mode==='orig'){
  var au=(p.audio||[]).filter(function(a){return a.audio_only!==false});
  if(p.platform==='spotify')o.push({l:'Mejor audio de la fuente',s:'Desde YouTube, sin recodificar',fmt:'bestaudio',k:160,best:1,label:'Opus'});
  else if(!au.length)o.push({l:'Mejor audio disponible',s:'Sin recodificar',fmt:'bestaudio',k:(p.audio[0]||{}).kbps||null,best:1,label:'Original'});
  else au.forEach(function(a,i){o.push({l:a.codec+(a.kbps?' '+a.kbps+' kbps':''),s:'Sin recodificar, .'+a.ext,fmt:a.id,k:a.kbps,best:i===0,label:a.codec+(a.kbps?' '+a.kbps+' kbps':'')})});
 }else if(mode==='comp'){
  o.push({l:'MP3 320 kbps',s:'Recodificado, máxima compatibilidad',fmt:'mp3-320',k:320,label:'MP3 320 kbps'});
  o.push({l:'MP3 192 kbps',s:'Recodificado, archivo más liviano',fmt:'mp3-192',k:192,label:'MP3 192 kbps'});
  o.push({l:'M4A AAC 256 kbps',s:'Para Apple y celulares',fmt:'m4a-256',k:256,label:'AAC 256 kbps'});
 }else{
  (p.video||[]).forEach(function(h,i){o.push({l:(h>=2160?'4K':h+'p')+' MP4',s:i===0?'Mejor video disponible':(h<=480?'Para ahorrar espacio':'Equilibrio de peso y nitidez'),fmt:String(h),v:h>=2160?20:h>=1440?10:h>=1080?6:h>=720?3:1.2,best:i===0,label:(h>=2160?'4K':h+'p')+' MP4'})});
 }
 return o;
}
function srcKbps(){if(info.type==='playlist')return null;var a=(info.audio||[])[0];return info.platform==='spotify'?160:(a&&a.kbps)||null}
function render(){
 var o=options(),p=info,isPl=p.type==='playlist',dur=isPl?selDur():p.duration;
 if(!o.length){$('opts').innerHTML='<p class="empty">No hay formatos de video para este enlace.</p>';$('meter').hidden=true;$('dl').disabled=true;$('est').textContent='';return}
 sel=Math.min(sel,o.length-1);var x=o[sel];
 $('opts').innerHTML=o.map(function(r,i){
  var sz=dur?(r.v?'≈ '+Math.round(r.v*dur/8)+' MB':(r.k?(isPl?'≈ ':'')+mb(r.k,dur):'')):'';
  return '<button type="button" class="opt" role="radio" aria-checked="'+(i===sel)+'" data-i="'+i+'"><div><b>'+esc(r.l)+'</b>'+(r.best?'<em>Mejor</em>':'')+'<br><span>'+esc(r.s)+'</span></div><span>'+sz+'</span></button>';
 }).join('');
 var sk=srcKbps();
 $('meter').hidden=!!x.v||!sk||!x.k;
 if(!$('meter').hidden){
  var s=Math.min(100,sk/320*100),out=Math.min(100,x.k/320*100);
  $('src').style.width=s+'%';$('ext').style.left=s+'%';$('ext').style.width=Math.max(0,out-s)+'%';
  $('mtext').textContent=x.k>sk+8?'La zona rayada no añade calidad: la fuente llega a unos '+sk+' kbps y convertir a '+x.k+' solo agranda el archivo.':(x.k<sk-8?'Archivo más liviano que la fuente, con una pequeña pérdida.':'Conservas toda la calidad que ofrece la fuente.');
 }
 if(isPl){
  var n=PSEL.filter(Boolean).length;
  $('est').textContent=n?('Duración '+mmss(dur)+', se guarda en la carpeta “'+p.title+'”'):'Selecciona al menos una canción';
  $('dl').disabled=!n;$('dl').textContent=n?'Descargar '+n+(mode==='vid'?(n===1?' video':' videos'):(n===1?' canción':' canciones')):'Descargar';
  return;
 }
 $('est').textContent=p.duration?'Duración '+mmss(p.duration):'';
 $('dl').disabled=false;$('dl').textContent='Descargar '+x.label;
}
function setMode(m){
 mode=m;sel=0;$('modes').style.setProperty('--i',['orig','comp','vid'].indexOf(m));
 document.querySelectorAll('#modes button').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.m===m);if(b.dataset.m==='vid')b.disabled=!(info&&info.video&&info.video.length)});
}
$('analyze').onclick=function(){analyze()};
$('url').addEventListener('keydown',function(e){if(e.key==='Enter')analyze()});
$('url').addEventListener('paste',function(){setTimeout(function(){analyze()},60)});
$('pasteBtn').onclick=function(){
 if(navigator.clipboard&&navigator.clipboard.readText){navigator.clipboard.readText().then(function(t){$('url').value=t.trim();analyze()},function(){$('url').focus();toast('Usa Ctrl+V para pegar el enlace.')})}
 else{$('url').focus();toast('Usa Ctrl+V para pegar el enlace.')}
};
$('modes').onclick=function(e){var b=e.target.closest('button');if(b&&!b.disabled){setMode(b.dataset.m);render()}};
$('opts').onclick=function(e){var b=e.target.closest('.opt');if(b){sel=+b.dataset.i;render()}};

$('dl').onclick=function(){
 if(!info)return;var x=options()[sel];if(!x)return;
 if(info.type==='playlist'){
  var gid='g'+Date.now().toString(36),list=info.entries.filter(function(e,i){return PSEL[i]});
  var items=list.map(function(e){
   var r={url:e.url,mode:mode,fmt:x.fmt,label:x.label,subdir:info.title,
    group:{id:gid,title:info.title,total:list.length,thumbnail:info.thumbnail,n:e.n},
    meta:{title:e.title,artist:e.artist,album:info.title,platform:info.platform,thumbnail:e.thumbnail||info.thumbnail,duration:e.duration,track:e.n}};
   if(info.platform==='spotify')r.spotify_track=e.url;
   return r;
  });
  GREQS[gid]=items;OPEN[gid]=false;
  $('dl').disabled=true;
  api('/api/download-batch',{items:items}).then(function(j){toast(j.count+' elementos agregados a la cola.');loadJobs()}).catch(function(e){toast(e.message)}).finally(function(){$('dl').disabled=false});
  return;
 }
 var req={url:info.url,mode:mode,fmt:x.fmt,label:x.label,
  meta:{title:info.title,artist:info.artist,album:info.album,year:info.year,platform:info.platform,thumbnail:info.thumbnail,duration:info.duration}};
 if(info.platform==='spotify'){var mm=(info.matches||[])[matchSel];if(!mm){toast('Elige una coincidencia primero.');return}req.source_url=mm.url}
 sendDownload(req);
};
function sendDownload(req){
 $('dl').disabled=true;
 api('/api/download',req).then(function(j){REQS[j.id]=req;toast('Agregado a la cola: '+req.meta.title);loadJobs()}).catch(function(e){toast(e.message)}).finally(function(){$('dl').disabled=false});
}

/* ---------- cola ---------- */
function loadJobs(){
 clearTimeout(pollT);
 api('/api/jobs').then(function(js){
  var finishedNow=JOBS.some(function(o){return o.status!=='done'&&js.some(function(n){return n.id===o.id&&n.status==='done'})});
  JOBS=js;renderJobs();if(finishedNow)loadLib();
 }).catch(function(){}).finally(function(){
  var active=JOBS.some(function(j){return !DONE_ST[j.status]});
  pollT=setTimeout(loadJobs,document.hidden?(active?3000:15000):(active?700:4000));
 });
}
function statusHTML(j){
 if(j.status==='done')return '<span class="done">'+esc(j.message)+'</span>';
 if(j.status==='error')return '<span class="bad">'+esc(j.message)+'</span>';
 if(j.status==='cancelled')return '<span>Cancelada</span>';
 return '<span>'+esc(j.message)+(j.speed?', '+esc(j.speed):'')+'</span>';
}
function renderJobs(){
 var act=JOBS.filter(function(j){return !DONE_ST[j.status]}).length;
 $('s1').textContent=act;
 $('clearJobs').hidden=!JOBS.some(function(j){return DONE_ST[j.status]});
 if(!JOBS.length){$('list').innerHTML='<div class="empty">Cada descarga aparece aquí con su carátula, artista y progreso.</div>';return}
 var units=[],gi={};
 JOBS.forEach(function(j){
  if(j.group){if(gi[j.group]===undefined){gi[j.group]=units.length;units.push({g:j.group,jobs:[]})}units[gi[j.group]].jobs.push(j)}
  else units.push({j:j});
 });
 $('list').innerHTML=units.map(function(u){return u.g?groupHTML(u):jobHTML(u.j)}).join('');
}
function jobHTML(j){
 var pl=PL[j.platform]||PL.otro,fb=cover(j.title,j.artist,[pl.d,pl.d2]);
 var src=j.cover_item?'/api/cover/'+j.cover_item+'?t='+TOKEN:img(j.cover_url);
 var acts='';
 if(j.status==='done'&&j.item_id)acts='<div class="acts"><button class="lk" data-open="'+j.item_id+'" type="button">Reproducir</button><button class="lk" data-folder="'+j.item_id+'" type="button">Mostrar en carpeta</button></div>';
 else if(j.status==='error'&&REQS[j.id])acts='<div class="acts"><button class="lk" data-retry="'+j.id+'" type="button">Reintentar</button></div>';
 else if(!DONE_ST[j.status]&&j.kind!=='setup')acts='<div class="acts"><button class="lk" data-cancel="'+j.id+'" type="button">Cancelar</button></div>';
 return '<div class="item">'+imgTag(src,fb,'','')+'<div style="min-width:0"><b>'+esc(j.title||'Tarea')+'</b><span class="who">'+esc(j.artist||pl.n)+'</span>'+
  '<div class="row">'+statusHTML(j)+(j.tag?'<span class="tag">'+esc(j.tag)+'</span>':'')+'</div>'+
  (!DONE_ST[j.status]?'<div class="bar"><i style="width:'+j.progress+'%"></i></div>':'')+acts+'</div></div>';
}
function groupHTML(u){
 var js=u.jobs,f=js[0],pl=PL[f.platform]||PL.otro,total=f.group_total||js.length;
 js.sort(function(a,b){return a.n-b.n});
 var done=0,err=0,canc=0,prog=0,act=0;
 js.forEach(function(j){if(j.status==='done')done++;else if(j.status==='error')err++;else if(j.status==='cancelled')canc++;else act++;prog+=DONE_ST[j.status]?100:j.progress});
 var parts=[done+' de '+total+' descargadas'];if(err)parts.push(err+' con error');if(canc)parts.push(canc+' canceladas');
 var cur=js.find(function(j){return j.status==='downloading'||j.status==='processing'});
 var fb=cover(f.group_title,'',[pl.d,pl.d2]);
 var acts='<button class="lk" type="button" data-toggle="'+u.g+'">'+(OPEN[u.g]?'Ocultar canciones':'Ver canciones')+'</button>';
 if(act)acts+='<button class="lk" type="button" data-gcancel="'+u.g+'">Cancelar lo pendiente</button>';
 if(!act&&(err||canc)&&GREQS[u.g])acts+='<button class="lk" type="button" data-gretry="'+u.g+'">Reintentar las que faltan</button>';
 var firstDone=js.find(function(j){return j.item_id});
 if(firstDone)acts+='<button class="lk" type="button" data-folder="'+firstDone.item_id+'">Abrir carpeta</button>';
 var det=OPEN[u.g]?'<div class="det">'+js.map(function(j){return '<div><span>'+(j.n?('0'+j.n).slice(-2)+'. ':'')+esc(j.title)+'</span>'+statusHTML(j)+'</div>'}).join('')+'</div>':'';
 return '<div class="grp"><div class="top2">'+imgTag(img(f.group_cover),fb,'','')+'<div style="min-width:0"><b>'+esc(f.group_title)+'</b><span class="sub">'+parts.join(', ')+'</span>'+
  (cur?'<span class="sub">Ahora: '+esc(cur.title)+'</span>':'')+'</div></div>'+
  (act?'<div class="bar"><i style="width:'+(prog/js.length).toFixed(1)+'%"></i></div>':'')+
  '<div class="acts">'+acts+'</div>'+det+'</div>';
}
$('list').onclick=function(e){
 var b=e.target.closest('button');if(!b)return;
 if(b.dataset.open)playItem(b.dataset.open);
 if(b.dataset.folder)api('/api/open',{id:b.dataset.folder,folder:true}).catch(function(e){toast(e.message)});
 if(b.dataset.retry)sendDownload(REQS[b.dataset.retry]);
 if(b.dataset.cancel)api('/api/cancel',{ids:[b.dataset.cancel]}).then(loadJobs);
 if(b.dataset.gcancel)api('/api/cancel',{group:b.dataset.gcancel}).then(function(){toast('Se cancelaron las descargas pendientes.');loadJobs()});
 if(b.dataset.toggle){OPEN[b.dataset.toggle]=!OPEN[b.dataset.toggle];renderJobs()}
 if(b.dataset.gretry){
  var g=b.dataset.gretry,failed={};
  JOBS.forEach(function(j){if(j.group===g&&(j.status==='error'||j.status==='cancelled'))failed[j.n]=1});
  var again=GREQS[g].filter(function(r){return failed[r.group.n]});
  api('/api/jobs/clear',{}).then(function(){return api('/api/download-batch',{items:again})}).then(function(j){toast(j.count+' elementos de nuevo en la cola.');loadJobs()}).catch(function(e){toast(e.message)});
 }
};
$('clearJobs').onclick=function(){api('/api/jobs/clear',{}).then(loadJobs)};

/* ---------- biblioteca ---------- */
var LV='grid',LS='new',LF={type:'',fmt:'',plat:''};
try{LV=localStorage.getItem('resonar-lv')||'grid';LS=localStorage.getItem('resonar-ls')||'new'}catch(e){}
var FMT={opus:'Opus',m4a:'AAC',mp3:'MP3',flac:'FLAC',ogg:'Vorbis',wav:'WAV',mp4:'MP4',webm:'WebM',mkv:'MKV'};
var TYPES={audio:'Música',video:'Video',stem:'Pistas separadas'};
function itemType(x){if(x.kind==='video')return 'video';if(/\((Instrumental|Voz)\)$/.test(x.title||'')||/^FLAC (instrumental|voz)/i.test(x.tag||''))return 'stem';return 'audio'}
function itemFmt(x){return FMT[x.ext]||(x.ext||'').toUpperCase()||'Otro'}
function hsize(b){if(!b)return '';if(b<1048576)return Math.max(1,Math.round(b/1024))+' KB';if(b<1073741824)return (b/1048576).toFixed(1).replace('.',',')+' MB';return (b/1073741824).toFixed(2).replace('.',',')+' GB'}
function hdur(sec){sec=Math.round(sec||0);var h=Math.floor(sec/3600),m=Math.round(sec%3600/60);return h?h+' h '+m+' min':m+' min'}
var MESES=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
function hdate(t){var d=new Date(t*1000);return d.getDate()+' '+MESES[d.getMonth()].slice(0,3)+' '+d.getFullYear()}
function dateGroup(t){
 var d=new Date(t*1000),now=new Date(),day=86400000;
 var start=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
 if(d.getTime()>=start)return 'Hoy';
 if(d.getTime()>=start-day)return 'Ayer';
 if(d.getTime()>=start-6*day)return 'Esta semana';
 if(d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear())return 'Este mes';
 var n=MESES[d.getMonth()];return n[0].toUpperCase()+n.slice(1)+' '+d.getFullYear();
}
function loadLib(){api('/api/library').then(function(l){LIB=l;$('s2').textContent=l.length;renderLib()}).catch(function(){})}
function filtered(){
 var q=($('q').value||'').toLowerCase().trim();
 return LIB.filter(function(x){
  if(q&&(x.title+' '+x.artist+' '+(x.album||'')).toLowerCase().indexOf(q)<0)return false;
  if(LF.type&&itemType(x)!==LF.type)return false;
  if(LF.fmt&&itemFmt(x)!==LF.fmt)return false;
  if(LF.plat&&(x.platform||'otro')!==LF.plat)return false;
  return true;
 });
}
function sorted(items){
 var cmp={
  new:function(a,b){return (b.date||0)-(a.date||0)},old:function(a,b){return (a.date||0)-(b.date||0)},
  title:function(a,b){return (a.title||'').localeCompare(b.title||'','es',{sensitivity:'base'})},
  artist:function(a,b){return (a.artist||'~').localeCompare(b.artist||'~','es',{sensitivity:'base'})||(a.title||'').localeCompare(b.title||'','es')},
  long:function(a,b){return (b.duration||0)-(a.duration||0)},big:function(a,b){return (b.size||0)-(a.size||0)}
 }[LS]||function(){return 0};
 return items.slice().sort(cmp);
}
function counts(key){var c={};LIB.forEach(function(x){var k=key(x);c[k]=(c[k]||0)+1});return c}
function renderFilters(){
 if(!LIB.length){$('lFilters').innerHTML='';return}
 var ct=counts(itemType),cf=counts(itemFmt),cp=counts(function(x){return x.platform||'otro'});
 function chips(group,label,map,names){
  var keys=Object.keys(map);if(keys.length<2&&!LF[group])return '';
  return '<div class="fgroup"><span>'+label+'</span>'+keys.sort(function(a,b){return map[b]-map[a]}).map(function(k){
   return '<button type="button" class="fchip" data-f="'+group+'" data-v="'+esc(k)+'" aria-pressed="'+(LF[group]===k)+'">'+esc(names?names(k):k)+'<b>'+map[k]+'</b></button>'}).join('')+'</div>';
 }
 var any=LF.type||LF.fmt||LF.plat;
 $('lFilters').innerHTML=chips('type','Tipo',ct,function(k){return TYPES[k]})+chips('fmt','Formato',cf)+chips('plat','Origen',cp,function(k){return (PL[k]||PL.otro).n})+
  (any?'<button class="lk fclear" type="button" data-clear="1">Quitar filtros</button>':'');
}
function cardHTML(x){
 var pl=PL[x.platform]||PL.otro,fb=cover(x.title,x.artist,[pl.d,pl.d2]),t=itemType(x);
 var src=x.cover?'/api/cover/'+x.id+'?t='+TOKEN:'';
 return '<div class="lc"><div class="art2">'+imgTag(src,fb,'','Carátula de '+x.title)+
  '<button class="play" type="button" data-play="'+x.id+'" aria-label="Reproducir '+esc(x.title)+'"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button></div>'+
  '<div class="lb"><b>'+esc(x.title)+'</b><small>'+esc(x.artist?x.artist+', ':'')+pl.n+'</small>'+
  '<div class="lmeta" style="margin-top:8px"><span class="kindb '+t+'">'+TYPES[t]+'</span><span class="tag">'+esc(x.tag)+'</span>'+(x.duration?'<span>'+mmss(x.duration)+'</span>':'')+(x.size?'<span>'+hsize(x.size)+'</span>':'')+'</div>'+
  '<div class="acts"><button class="lk" type="button" data-folder="'+x.id+'">Mostrar en carpeta</button>'+(t!=='video'?'<button class="lk" type="button" data-tool="'+x.id+'">Separar voz</button>':'')+'<button class="lk" type="button" data-del="'+x.id+'">Quitar</button></div>'+
  (t!=='video'?'<div class="tools" data-tools="'+x.id+'" hidden></div>':'')+'</div></div>';
}
var IC={
 folder:'<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
 split:'<svg viewBox="0 0 24 24"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg>',
 del:'<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
 play:'<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>'
};
function rowHTML(x){
 var pl=PL[x.platform]||PL.otro,fb=cover(x.title,x.artist,[pl.d,pl.d2]),t=itemType(x);
 var src=x.cover?'/api/cover/'+x.id+'?t='+TOKEN:'';
 return '<div class="lrow">'+imgTag(src,fb,'','')+
  '<div class="nm"><b title="'+esc(x.title)+'">'+esc(x.title)+'</b><small>'+esc(x.artist||pl.n)+(x.album?', '+esc(x.album):'')+'</small></div>'+
  '<span class="c-kind"><span class="kindb '+t+'">'+TYPES[t]+'</span></span><span class="c-fmt"><span class="tag">'+esc(x.tag)+'</span></span>'+
  '<span class="num c-dur">'+(x.duration?mmss(x.duration):'')+'</span><span class="num c-size">'+hsize(x.size)+'</span><span class="num c-date">'+(x.date?hdate(x.date):'')+'</span>'+
  '<span class="ibtns"><button class="ib play2" type="button" data-play="'+x.id+'" title="Reproducir" aria-label="Reproducir '+esc(x.title)+'">'+IC.play+'</button>'+
  '<button class="ib" type="button" data-folder="'+x.id+'" title="Mostrar en carpeta" aria-label="Mostrar en carpeta">'+IC.folder+'</button>'+
  (t!=='video'?'<button class="ib" type="button" data-tool="'+x.id+'" title="Separar voz" aria-label="Separar voz">'+IC.split+'</button>':'')+
  '<button class="ib" type="button" data-del="'+x.id+'" title="Quitar de la biblioteca" aria-label="Quitar de la biblioteca">'+IC.del+'</button></span>'+
  (t!=='video'?'<div class="tools" data-tools="'+x.id+'" hidden></div>':'')+'</div>';
}
function renderLib(){
 document.querySelectorAll('#lView button').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.lv===LV)});
 $('lSort').value=LS;
 renderFilters();
 var items=sorted(filtered());
 var tot=LIB.reduce(function(a,x){return a+(x.size||0)},0),dur=LIB.reduce(function(a,x){return a+(x.duration||0)},0);
 $('libSum').textContent=!LIB.length?'':(items.length<LIB.length?'Mostrando '+items.length+' de '+LIB.length+'. ':'')+LIB.length+(LIB.length===1?' elemento':' elementos')+', '+hsize(tot)+(dur?', '+hdur(dur)+' en total':'');
 if(!LIB.length){$('lg').innerHTML='<div class="empty">Todavía no hay descargas. Pega un enlace en Descargar para empezar.</div>';return}
 if(!items.length){$('lg').innerHTML='<div class="empty">Nada coincide con la búsqueda o los filtros. <button class="lk" type="button" data-clear="1">Quitar filtros</button></div>';return}
 var groups=[];
 if(LS==='new'||LS==='old'){var cur=null;items.forEach(function(x){var g=x.date?dateGroup(x.date):'Sin fecha';if(!cur||cur.name!==g){cur={name:g,items:[]};groups.push(cur)}cur.items.push(x)})}
 else groups=[{name:'',items:items}];
 $('lg').innerHTML=groups.map(function(g){
  var head=g.name?'<h3>'+esc(g.name)+' <span>'+g.items.length+'</span></h3>':'';
  if(LV==='list')return '<section class="lgroup">'+head+'<div class="ll"><div class="lrow lhd"><span></span><span>Título</span><span class="c-kind">Tipo</span><span class="c-fmt">Formato</span><span class="c-dur">Duración</span><span class="c-size">Tamaño</span><span class="c-date">Fecha</span><span></span></div>'+g.items.map(rowHTML).join('')+'</div></section>';
  return '<section class="lgroup">'+head+'<div class="lg">'+g.items.map(cardHTML).join('')+'</div></section>';
 }).join('');
}
function toolsHTML(id){
 if(!ENG.stems)return 'El módulo de separación no está instalado.<div class="tb"><button class="btn line sm" type="button" data-install="1">Instalar módulo (≈ 2 GB)</button></div>';
 return 'Elige qué pista quieres. Se guarda como un archivo nuevo en FLAC.<div class="tb"><select aria-label="Calidad de separación" data-q="'+id+'"><option value="rapido">Rápida (recomendada)</option>'+(ENG.ram_gb&&ENG.ram_gb<7.5?'<option value="calidad" disabled>Máxima calidad (necesita 8 GB de RAM)</option>':'<option value="calidad">Máxima calidad (lenta, usa 4 a 6 GB de RAM)</option>')+'</select><button class="btn line sm" type="button" data-stem="instrumental" data-id="'+id+'">Solo instrumental</button><button class="btn line sm" type="button" data-stem="vocals" data-id="'+id+'">Solo voz</button></div>';
}
function clearFilters(){LF={type:'',fmt:'',plat:''};$('q').value='';renderLib()}
$('lFilters').onclick=function(e){
 var b=e.target.closest('button');if(!b)return;
 if(b.dataset.clear){clearFilters();return}
 LF[b.dataset.f]=LF[b.dataset.f]===b.dataset.v?'':b.dataset.v;renderLib();
};
$('lView').onclick=function(e){var b=e.target.closest('button');if(!b)return;LV=b.dataset.lv;try{localStorage.setItem('resonar-lv',LV)}catch(x){}renderLib()};
$('lSort').onchange=function(){LS=this.value;try{localStorage.setItem('resonar-ls',LS)}catch(x){}renderLib()};
$('lg').onclick=function(e){
 var b=e.target.closest('button');if(!b)return;
 if(b.dataset.clear){clearFilters();return}
 if(b.dataset.play){var it=LIB.find(function(x){return x.id===b.dataset.play});if(it&&it.kind==='video')api('/api/open',{id:it.id}).catch(function(e){toast(e.message)});else playItem(b.dataset.play)}
 if(b.dataset.folder)api('/api/open',{id:b.dataset.folder,folder:true}).catch(function(e){toast(e.message)});
 if(b.dataset.tool){var t=document.querySelector('[data-tools="'+b.dataset.tool+'"]');t.innerHTML=toolsHTML(b.dataset.tool);t.hidden=!t.hidden}
 if(b.dataset.install){installStems()}
 if(b.dataset.stem){
  var q=document.querySelector('[data-q="'+b.dataset.id+'"]');
  api('/api/stems',{id:b.dataset.id,which:b.dataset.stem,quality:q?q.value:'rapido'}).then(function(){toast('Separación agregada a la cola.');loadJobs();view('dl')}).catch(function(e){toast(e.message)});
 }
 if(b.dataset.del){
  var isIcon=b.classList.contains('ib');
  if(b.dataset.confirm){api('/api/library/remove',{id:b.dataset.del}).then(function(){toast('Quitado de la biblioteca. El archivo sigue en tu carpeta.');loadLib()});}
  else{b.dataset.confirm='1';if(isIcon){b.title='Pulsa otra vez para quitar';toast('Pulsa otra vez para quitarlo de la biblioteca.')}else b.textContent='Confirmar quitar';
   setTimeout(function(){if(b.isConnected){delete b.dataset.confirm;if(isIcon)b.title='Quitar de la biblioteca';else b.textContent='Quitar'}},3500)}
 }
};
$('q').oninput=renderLib;
$('openDir').onclick=function(){api('/api/open-folder',{}).catch(function(e){toast(e.message)})};

/* ---------- reproductor ---------- */
function playItem(id){
 var x=LIB.find(function(i){return i.id===id});
 if(!x){loadLib();toast('Abriendo…');return api('/api/open',{id:id}).catch(function(e){toast(e.message)})}
 if(x.kind==='video'){return api('/api/open',{id:id}).catch(function(e){toast(e.message)})}
 var pl=PL[x.platform]||PL.otro;
 $('pImg').src=x.cover?'/api/cover/'+x.id+'?t='+TOKEN:cover(x.title,x.artist,[pl.d,pl.d2]);
 $('pT').textContent=x.title;$('pA').textContent=x.artist+' · '+x.tag;
 $('player').hidden=false;R.style.setProperty('--pb','84px');var a=$('audio');a.src='/api/media/'+x.id+'?t='+TOKEN;
 a.play().catch(function(){toast('Este formato no se puede reproducir aquí. Usa Mostrar en carpeta.')});
}
$('audio').addEventListener('error',function(){if($('audio').src)toast('Este formato no se puede reproducir aquí. Usa Mostrar en carpeta.')});
$('pClose').onclick=function(){var a=$('audio');a.pause();a.removeAttribute('src');a.load();$('player').hidden=true;R.style.setProperty('--pb','0px')};

/* ---------- ajustes ---------- */
function loadStatus(){
 return api('/api/status').then(function(s){
  ENG=s.engine;SET=s.settings;
  $('foot').textContent='ResonarDown '+s.version;$('about').textContent='ResonarDown '+s.version+'. '+s.copyright+'.';
  $('dirIn').value=SET.download_dir;$('cookies').value=SET.cookies_browser||'';$('par').value=String(SET.max_parallel||2);
  var ok=ENG.ffmpeg&&ENG.deno;
  $('engDot').className='dot'+(ok?'':' w');$('engTxt').textContent=ok?'Motor listo':'Revisa Ajustes';
  $('eng').innerHTML=[['Motor de descargas','Versión '+ENG.ytdlp,true],['Conversión de audio',ENG.ffmpeg?'Instalada':'Falta: ejecuta Instalar.bat',ENG.ffmpeg],['Soporte de YouTube',ENG.deno?'Instalado':'Falta: actualiza el motor',ENG.deno],['Separación de voz',ENG.stems?'Instalada':'No instalada',ENG.stems]].map(function(r){return '<div><small>'+r[0]+'</small><span class="'+(r[2]?'ok':'wn')+'">'+r[1]+'</span></div>'}).join('');
  $('stemsBox').innerHTML=ENG.stems?'<span class="ok">Instalado.</span> Úsalo desde la Biblioteca con el botón Separar voz.':'<button class="btn line sm" type="button" id="instStems">Instalar módulo (≈ 2 GB)</button>';
  if($('instStems'))$('instStems').onclick=installStems;
 }).catch(function(e){toast(e.message)});
}
function installStems(){api('/api/install-stems',{}).then(function(){toast('Instalando el módulo. Verás el progreso en Actividad.');view('dl');loadJobs()}).catch(function(e){toast(e.message)})}
$('upd').onclick=function(){api('/api/update-engine',{}).then(function(){toast('Actualizando el motor. Verás el progreso en Actividad.');view('dl');loadJobs()}).catch(function(e){toast(e.message)})};
$('dirSave').onclick=function(){api('/api/settings',{download_dir:$('dirIn').value}).then(function(s){SET=s;$('dirIn').value=s.download_dir;toast('Carpeta guardada.')}).catch(function(e){toast(e.message)})};
$('dirPick').onclick=function(){
 if(window.pywebview&&window.pywebview.api&&window.pywebview.api.choose_folder){window.pywebview.api.choose_folder().then(function(p){if(p){$('dirIn').value=p;$('dirSave').click()}})}
 else{$('dirIn').focus();toast('Escribe la ruta de la carpeta y pulsa Guardar.')}
};
$('uninst').onclick=function(){$('uninstAsk').hidden=false;this.hidden=true};
$('uninstNo').onclick=function(){$('uninstAsk').hidden=true;$('uninst').hidden=false};
$('uninstYes').onclick=function(){api('/api/uninstall',{}).then(function(){toast('Se abrió el desinstalador. Sigue los pasos en esa ventana.')}).catch(function(e){toast(e.message)})};
$('par').onchange=function(){api('/api/settings',{max_parallel:+this.value}).then(function(){toast('Ajuste guardado. Se aplica a las próximas descargas.')}).catch(function(e){toast(e.message)})};
$('cookies').onchange=function(){api('/api/settings',{cookies_browser:this.value}).then(function(){toast('Ajuste guardado.')}).catch(function(e){toast(e.message)})};

/* ---------- navegación y tema ---------- */
function view(v){
 document.querySelectorAll('.view').forEach(function(s){s.classList.toggle('on',s.id==='v-'+v)});
 document.querySelectorAll('#nav button').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.v===v)});
 if(v==='lib')loadLib();if(v==='set')loadStatus();
}
$('nav').onclick=function(e){var b=e.target.closest('button');if(b)view(b.dataset.v)};
try{var th=localStorage.getItem('resonar-theme');if(th)R.dataset.theme=th}catch(e){}
$('theme').onclick=function(){
 var dark=R.dataset.theme?R.dataset.theme==='dark':matchMedia('(prefers-color-scheme: dark)').matches;
 R.dataset.theme=dark?'light':'dark';try{localStorage.setItem('resonar-theme',R.dataset.theme)}catch(e){}
};

/* ---------- actualizaciones ---------- */
var UPD=null;
function showUpdate(u){
 UPD=u;var later='';try{later=localStorage.getItem('resonar-later')||''}catch(e){}
 var st=$('updStatus');
 if(!u.configured){st.textContent='Versión '+u.current+'. Las actualizaciones automáticas todavía no están configuradas.';$('updCheck').hidden=true;return}
 $('updCheck').hidden=false;
 if(u.error){st.textContent='Versión '+u.current+'. '+u.error;$('updNow2').hidden=true;return}
 if(u.available){
  st.textContent='Hay una versión nueva: '+u.latest+' (tienes la '+u.current+').';$('updNow2').hidden=false;
  $('updTitle').textContent='ResonarDown '+u.latest+' ya está disponible';
  $('updNotes').textContent=u.notes||'Esta versión no incluye notas.';$('updNotesBtn').hidden=!u.notes;
  $('updBar').hidden=later===u.latest;
 }else{st.textContent='Tienes la última versión ('+u.current+').';$('updNow2').hidden=true;$('updBar').hidden=true}
}
function checkUpdate(force){
 return api('/api/update/check'+(force?'?force=1':'')).then(showUpdate).catch(function(){});
}
function applyUpdate(){
 var active=JOBS.some(function(j){return !DONE_ST[j.status]&&j.kind!=='update'});
 var b=$('updNow');
 if(active&&!b.dataset.sure){b.dataset.sure='1';b.textContent='Hay descargas en curso. Actualizar igual';$('updNow2').dataset.sure='1';$('updNow2').textContent=b.textContent;toast('Si actualizas ahora, las descargas en curso se detienen.');return}
 $('updOver').hidden=false;$('updOverMsg').textContent='Descargando la versión nueva…';
 api('/api/update/apply',{}).then(function(r){
  var t=setInterval(function(){
   api('/api/jobs').then(function(js){
    var j=js.find(function(x){return x.id===r.job});if(!j)return;
    $('updOverMsg').textContent=j.message;
    if(j.status==='error'){clearInterval(t);$('updOver').hidden=true;toast(j.message)}
   }).catch(function(){clearInterval(t);$('updOverMsg').textContent='ResonarDown se está actualizando y volverá a abrirse solo en unos segundos.'});
  },500);
 }).catch(function(e){$('updOver').hidden=true;toast(e.message)});
}
$('updNow').onclick=applyUpdate;$('updNow2').onclick=applyUpdate;
$('updLater').onclick=function(){try{localStorage.setItem('resonar-later',UPD.latest)}catch(e){}$('updBar').hidden=true;toast('Te lo recordaremos con la próxima versión. También puedes actualizar desde Ajustes.')};
$('updNotesBtn').onclick=function(){var n=$('updNotes');n.hidden=!n.hidden;this.textContent=n.hidden?'Ver novedades':'Ocultar novedades'};
$('updCheck').onclick=function(){var b=this;b.disabled=true;b.textContent='Buscando…';checkUpdate(true).then(function(){b.disabled=false;b.textContent='Buscar actualizaciones';if(UPD&&!UPD.available&&!UPD.error)toast('Tienes la última versión.')})};

document.addEventListener('visibilitychange',function(){if(!document.hidden)loadJobs()});
paint(D);loadStatus();loadLib();loadJobs();setTimeout(function(){checkUpdate(false)},1500);
setTimeout(function(){$('url').focus()},200);
