"""Servidor local (solo 127.0.0.1) que conecta la interfaz con el motor.
© 2026 VCARD26."""
import ipaddress
import json
import mimetypes
import os
import secrets
import socket
import subprocess
import sys
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import engine, store, updater

mimetypes.add_type("font/woff2", ".woff2")
ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "ui"
TOKEN = secrets.token_urlsafe(24)
_img_cache = {}
_img_lock = threading.Lock()
MAX_BODY = 1024 * 1024            # 1 MB por pedido: más que suficiente para la interfaz
MAX_IMG = 8 * 1024 * 1024
# Solo estos tipos se abren con su programa; cualquier otro se muestra en su carpeta.
OPENABLE = {".opus", ".ogg", ".m4a", ".mp3", ".flac", ".wav", ".aac", ".mp4", ".webm", ".mkv", ".m4v", ".mov"}
CSP = ("default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
       "font-src 'self'; connect-src 'self'; media-src 'self'; base-uri 'none'; form-action 'none'; "
       "frame-ancestors 'none'")
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
}


def is_public_host(host: str) -> bool:
    """True si el nombre resuelve solo a direcciones públicas de internet."""
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if not ip.is_global:
            return False
    return bool(infos)


def open_path(path: Path, select=False):
    if not select and path.suffix.lower() not in OPENABLE:
        select = True   # nunca ejecutar archivos que no sean música o video
    if sys.platform == "win32":
        if select:
            subprocess.Popen(["explorer", "/select,", str(path)])
        else:
            os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(path)] if select else ["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path.parent if select else path)])


class Handler(BaseHTTPRequestHandler):
    server_version = "ResonarDown"

    def log_message(self, *a):
        pass

    # ---------- respuestas ----------
    def _send(self, code, body: bytes, ctype="application/json; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        if "Cache-Control" not in (extra or {}):
            self.send_header("Cache-Control", "no-store")
        for k, v in SECURITY_HEADERS.items():
            self.send_header(k, v)
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, data, code=200):
        self._send(code, json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def _err(self, msg, code=400):
        self._json({"error": msg}, code)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return None
        if n <= 0:
            return {}
        if n > MAX_BODY:
            return None
        try:
            data = json.loads(self.rfile.read(n).decode("utf-8"))
            return data if isinstance(data, dict) else None
        except Exception:
            return None

    def _authorized(self, qs):
        got = self.headers.get("X-ResonarDown-Token") or qs.get("t", [""])[0]
        return bool(got) and secrets.compare_digest(got.encode(), TOKEN.encode())

    def _trusted_origin(self):
        """Bloquea páginas web que intenten hablar con la app (incluido DNS rebinding).

        El servidor solo responde si el pedido va dirigido a 127.0.0.1 o localhost
        en su propio puerto, y si viene de la propia app.
        """
        port = self.server.server_address[1]
        allowed = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if (self.headers.get("Host") or "").lower() not in allowed:
            return False
        origin = self.headers.get("Origin")
        if origin and origin.lower() not in {"http://" + h for h in allowed}:
            return False
        site = self.headers.get("Sec-Fetch-Site")
        if site and site not in ("same-origin", "none"):
            return False
        return True

    # ---------- GET ----------
    def do_GET(self):
        if not self._trusted_origin():
            return self._err("No autorizado", 403)
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        p = u.path
        if p in ("/", "/index.html"):
            html = (UI / "index.html").read_text(encoding="utf-8")
            html = html.replace("__RESONAR_TOKEN__", TOKEN).replace("__RD_VERSION__", store.APP_VERSION)
            return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8",
                              {"Content-Security-Policy": CSP})
        if p.startswith("/ui/"):
            f = (UI / p[4:]).resolve()
            if UI in f.parents and f.is_file():
                return self._send(200, f.read_bytes(), mimetypes.guess_type(f.name)[0] or "application/octet-stream",
                                  {"Cache-Control": "max-age=86400"})
            return self._err("No encontrado", 404)
        if not p.startswith("/api/"):
            return self._err("No encontrado", 404)
        if not self._authorized(qs):
            return self._err("No autorizado", 403)
        try:
            if p == "/api/status":
                return self._json({"engine": engine.status(), "settings": store.get_settings(),
                                   "os": sys.platform, "version": store.APP_VERSION,
                                   "copyright": store.COPYRIGHT})
            if p == "/api/jobs":
                return self._json(engine.jobs_list())
            if p == "/api/update/check":
                return self._json(updater.check(force=qs.get("force", ["0"])[0] == "1"))
            if p == "/api/library":
                return self._json(store.library())
            if p == "/api/img":
                return self._proxy_img(qs.get("u", [""])[0])
            if p.startswith("/api/cover/"):
                f = store.COVERS / (Path(p).name + ".jpg")
                if f.exists():
                    return self._send(200, f.read_bytes(), "image/jpeg", {"Cache-Control": "max-age=86400"})
                return self._err("Sin carátula", 404)
            if p.startswith("/api/media/"):
                return self._media(Path(p).name)
        except engine.UserError as e:
            return self._err(str(e))
        except Exception as e:
            return self._err(engine.friendly_error(e), 500)
        return self._err("No encontrado", 404)

    def _proxy_img(self, url):
        parts = urllib.parse.urlparse(url)
        if parts.scheme not in ("http", "https") or not parts.hostname:
            return self._err("URL inválida")
        if not is_public_host(parts.hostname):
            return self._err("Solo se cargan imágenes de internet", 403)
        with _img_lock:
            hit = _img_cache.get(url)
        if not hit:
            data = engine.http_get(url, timeout=15, limit=MAX_IMG)
            kind = None
            if data[:3] == b"\xff\xd8\xff":
                kind = "image/jpeg"
            elif data[:4] == b"\x89PNG":
                kind = "image/png"
            elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
                kind = "image/webp"
            elif data[:6] in (b"GIF87a", b"GIF89a"):
                kind = "image/gif"
            if not kind:
                return self._err("No es una imagen", 415)
            hit = (data, kind)
            with _img_lock:
                if len(_img_cache) > 80:
                    _img_cache.clear()
                _img_cache[url] = hit
        return self._send(200, hit[0], hit[1], {"Cache-Control": "max-age=3600"})

    def _media(self, item_id):
        item = store.library_get(item_id)
        if not item or not Path(item["path"]).exists():
            return self._err("No encontrado", 404)
        f = Path(item["path"])
        size = f.stat().st_size
        ctype = {".opus": "audio/ogg", ".ogg": "audio/ogg", ".m4a": "audio/mp4", ".mp3": "audio/mpeg",
                 ".flac": "audio/flac", ".mp4": "video/mp4", ".webm": "video/webm"}.get(f.suffix.lower(), "application/octet-stream")
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        if rng:
            try:
                if not rng.startswith("bytes=") or "," in rng:
                    raise ValueError
                a, _, b = rng[6:].partition("-")
                start = int(a) if a else max(0, size - int(b))
                end = min(int(b), size - 1) if a and b else size - 1
                if start < 0 or start > end:
                    raise ValueError
            except ValueError:
                return self._send(416, b"", "text/plain", {"Content-Range": f"bytes */{size}"})
        length = end - start + 1
        self.send_response(206 if rng else 200)
        self.send_header("Content-Type", ctype)
        for k, v in SECURITY_HEADERS.items():
            self.send_header(k, v)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if rng:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        with open(f, "rb") as fh:
            fh.seek(start)
            left = length
            while left > 0:
                chunk = fh.read(min(262144, left))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    break
                left -= len(chunk)

    # ---------- POST ----------
    def do_POST(self):
        if not self._trusted_origin():
            return self._err("No autorizado", 403)
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        if not self._authorized(qs):
            return self._err("No autorizado", 403)
        if "json" not in (self.headers.get("Content-Type") or "") and int(self.headers.get("Content-Length") or 0):
            return self._err("Formato no admitido", 415)
        b = self._body()
        if b is None:
            return self._err("Pedido no válido", 400)
        p = u.path
        try:
            if p == "/api/info":
                return self._json(engine.get_info(b.get("url", ""), bool(b.get("playlist"))))
            if p == "/api/download":
                return self._json(engine.start_download(b))
            if p == "/api/download-batch":
                return self._json(engine.start_batch(b.get("items") or []))
            if p == "/api/cancel":
                return self._json(engine.cancel_jobs(b.get("ids"), b.get("group")))
            if p == "/api/uninstall":
                bat = ROOT / "Desinstalar.bat"
                if sys.platform != "win32" or not bat.exists():
                    return self._err("El desinstalador solo está disponible en Windows.")
                subprocess.Popen(["cmd.exe", "/c", "start", "", str(bat)], cwd=str(ROOT))
                return self._json({"ok": True})
            if p == "/api/jobs/clear":
                with engine._jobs_lock:
                    for k in [k for k, j in engine.JOBS.items() if j["status"] in ("done", "error", "cancelled")]:
                        engine.JOBS.pop(k, None)
                return self._json({"ok": True})
            if p == "/api/stems":
                return self._json(engine.start_stems(b.get("id", ""), b.get("which", "instrumental"),
                                                     b.get("quality", "rapido")))
            if p == "/api/open":
                item = store.library_get(b.get("id", ""))
                if not item or not Path(item["path"]).exists():
                    return self._err("El archivo ya no está en su carpeta.")
                open_path(Path(item["path"]), select=bool(b.get("folder")))
                return self._json({"ok": True})
            if p == "/api/open-folder":
                open_path(store.download_dir())
                return self._json({"ok": True})
            if p == "/api/library/remove":
                item = store.library_get(b.get("id", ""))
                store.library_remove(b.get("id", ""))
                if item and b.get("delete_file"):
                    f = Path(item["path"]).resolve()
                    if store.download_dir().resolve() in f.parents:   # solo archivos de la carpeta de descargas
                        f.unlink(missing_ok=True)
                return self._json({"ok": True})
            if p == "/api/settings":
                if "cookies_browser" in b and b["cookies_browser"] not in ("", "firefox", "edge", "chrome"):
                    return self._err("Elige un navegador de la lista.")
                if "download_dir" in b:
                    d = Path(str(b["download_dir"])).expanduser()
                    if not d.is_absolute():
                        return self._err("Elige una carpeta completa, por ejemplo C:\\Users\\Tu\\Music.")
                    try:
                        d.mkdir(parents=True, exist_ok=True)
                    except Exception:
                        return self._err("No se pudo usar esa carpeta. Elige otra.")
                    b["download_dir"] = str(d)
                if "max_parallel" in b:
                    try:
                        b["max_parallel"] = max(1, min(4, int(b["max_parallel"])))
                    except Exception:
                        return self._err("Elige un número de descargas entre 1 y 4.")
                return self._json(store.update_settings(b))
            if p == "/api/update/apply":
                return self._json(updater.apply(on_exit=lambda: os._exit(0)))
            if p == "/api/update-engine":
                return self._json(engine.update_engine())
            if p == "/api/install-stems":
                return self._json(engine.install_stems())
        except engine.UserError as e:
            return self._err(str(e))
        except Exception as e:
            return self._err(engine.friendly_error(e), 500)
        return self._err("No encontrado", 404)


def start(port=0):
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    return srv
