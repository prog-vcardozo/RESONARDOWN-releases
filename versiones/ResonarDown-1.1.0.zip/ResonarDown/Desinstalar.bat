@echo off
rem ResonarDown. (c) 2026 VCARD26.
rem Copia el desinstalador a la carpeta temporal para poder borrar esta carpeta por completo.
copy /y "%~dp0tools\desinstalar.ps1" "%TEMP%\resonar-desinstalar.ps1" >nul
cd /d "%TEMP%"
start "Desinstalar ResonarDown" powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\resonar-desinstalar.ps1" -AppDir "%~dp0."
exit
