﻿# ResonarDown: desinstalador completo.
# © 2026 VCARD26.
param([string]$AppDir)
$ErrorActionPreference = 'SilentlyContinue'
$Host.UI.RawUI.WindowTitle = 'Desinstalar ResonarDown'
Set-Location $env:TEMP

$AppDir = [IO.Path]::GetFullPath($AppDir).TrimEnd('\')
$Data = Join-Path $env:APPDATA 'ResonarDown'
$Key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ResonarDown'
# Restos del nombre anterior (Resonar, hasta la 1.0.0)
$DataOld = Join-Path $env:APPDATA 'Resonar'
$KeyOld = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Resonar'
if (-not (Test-Path -LiteralPath $Data) -and (Test-Path -LiteralPath $DataOld)) { $Data = $DataOld }

function Ask([string]$q, [string]$def = 'N') {
    $hint = if ($def -eq 'S') { '(S/n)' } else { '(s/N)' }
    $r = Read-Host "  $q $hint"
    if ([string]::IsNullOrWhiteSpace($r)) { $r = $def }
    return $r.Trim().ToUpper().StartsWith('S')
}
function Remove-Hard([string]$path) {
    for ($i = 0; $i -lt 6 -and (Test-Path -LiteralPath $path); $i++) {
        Remove-Item -LiteralPath $path -Recurse -Force
        if (Test-Path -LiteralPath $path) { Start-Sleep -Milliseconds 800 }
    }
    return -not (Test-Path -LiteralPath $path)
}

Write-Host ''
Write-Host '  =========================================='
Write-Host '    Desinstalar ResonarDown'
Write-Host '    © 2026 VCARD26'
Write-Host '  =========================================='
Write-Host ''
Write-Host "  Carpeta de la aplicación: $AppDir"
Write-Host "  Datos (ajustes, biblioteca, carátulas, modelos): $Data"
Write-Host ''
if (-not (Ask '¿Desinstalar ResonarDown por completo?' 'N')) { Write-Host '  No se hizo ningún cambio.'; Start-Sleep 2; Remove-Item -LiteralPath $PSCommandPath -Force; exit }

# 1. Cerrar ResonarDown y sus procesos (ventana, separación de voz, navegador interno)
Write-Host ''
Write-Host '  Cerrando ResonarDown...'
Get-CimInstance Win32_Process | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and (
        $_.CommandLine -like "*$AppDir*" -or $_.CommandLine -like "*$Data*" -or $_.CommandLine -like "*$DataOld*")
} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep -Seconds 1

# 2. Descargas: solo los archivos que bajó ResonarDown, nunca otros archivos de la carpeta
$downloadDir = Join-Path ([Environment]::GetFolderPath('MyMusic')) 'ResonarDown'
try {
    $s = Get-Content (Join-Path $Data 'settings.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($s.download_dir) { $downloadDir = $s.download_dir }
} catch { }
$files = @()
try {
    $lib = Get-Content (Join-Path $Data 'library.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $files = @($lib | ForEach-Object { $_.path } | Where-Object { $_ -and (Test-Path -LiteralPath $_) })
} catch { }
if ($files.Count -gt 0) {
    Write-Host ''
    if (Ask "¿Borrar también tus $($files.Count) descargas de $downloadDir ?" 'N') {
        foreach ($f in $files) { Remove-Item -LiteralPath $f -Force }
        if (Test-Path -LiteralPath $downloadDir) {
            Get-ChildItem -LiteralPath $downloadDir -Recurse -Directory | Sort-Object { $_.FullName.Length } -Descending |
                Where-Object { -not (Get-ChildItem -LiteralPath $_.FullName -Force) } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force }
            if (-not (Get-ChildItem -LiteralPath $downloadDir -Force)) { Remove-Item -LiteralPath $downloadDir -Force }
        }
        Write-Host '  Descargas borradas.'
    } else {
        Write-Host "  Tus descargas se quedan en $downloadDir"
    }
}

# 3. Componentes que instaló ResonarDown (solo si los instaló el instalador de ResonarDown)
$reg = Get-ItemProperty -Path $Key -ErrorAction SilentlyContinue
if (-not $reg) { $reg = Get-ItemProperty -Path $KeyOld -ErrorAction SilentlyContinue }
$winget = Get-Command winget -ErrorAction SilentlyContinue
if ($winget -and $reg) {
    if ($reg.InstalledFFmpeg -eq 1) {
        Write-Host ''
        if (Ask '¿Quitar también FFmpeg? Lo instaló ResonarDown; otros programas podrían usarlo.' 'N') {
            winget uninstall -e --id Gyan.FFmpeg --accept-source-agreements | Out-Host
        }
    }
    if ($reg.InstalledPython -eq 1) {
        Write-Host ''
        if (Ask '¿Quitar también Python 3.12? Lo instaló ResonarDown; otros programas podrían usarlo.' 'N') {
            winget uninstall -e --id Python.Python.3.12 --accept-source-agreements | Out-Host
        }
    }
}

# 4. Caché de instalación de Python
$pipCache = Join-Path $env:LOCALAPPDATA 'pip\Cache'
if (Test-Path -LiteralPath $pipCache) {
    Write-Host ''
    if (Ask '¿Borrar también la caché de instalación de Python (pip)? Libera espacio; si usas Python para otras cosas, se vuelve a crear sola.' 'S') {
        [void](Remove-Hard $pipCache)
    }
}

# 5. Accesos directos (escritorio, menú Inicio, barra de tareas)
Write-Host ''
Write-Host '  Quitando accesos directos...'
$links = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'ResonarDown.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\ResonarDown.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\ResonarDown.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\StartMenu\ResonarDown.lnk')
)
$links += $links | ForEach-Object { $_ -replace 'ResonarDown\.lnk$', 'Resonar.lnk' }
foreach ($l in $links) { Remove-Item -LiteralPath $l -Force }

# 6. Datos de la aplicación y cachés que dejaba la versión anterior
Write-Host '  Borrando ajustes, biblioteca, carátulas, modelos y cachés...'
$okData = Remove-Hard $Data
if (Test-Path -LiteralPath $DataOld) { $okData = (Remove-Hard $DataOld) -and $okData }
[void](Remove-Hard (Join-Path $env:USERPROFILE '.cache\yt-dlp'))
if (-not (Get-Command deno -ErrorAction SilentlyContinue)) { [void](Remove-Hard (Join-Path $env:LOCALAPPDATA 'deno')) }
[void](Remove-Hard (Join-Path $env:TEMP 'audio-separator-models'))

# 7. Registro de Windows
Remove-Item -Path $Key -Recurse -Force
Remove-Item -Path $KeyOld -Recurse -Force

# 8. Carpeta de la aplicación (solo si de verdad es la de ResonarDown)
$okApp = $true
if ((Test-Path -LiteralPath (Join-Path $AppDir 'app.py')) -and (Test-Path -LiteralPath (Join-Path $AppDir 'core'))) {
    Write-Host '  Borrando la carpeta de la aplicación...'
    $okApp = Remove-Hard $AppDir
}

Write-Host ''
if ($okApp -and $okData) {
    Write-Host '  ResonarDown se desinstaló por completo.'
} else {
    if (-not $okApp) { Write-Host "  No se pudo borrar del todo $AppDir. Cierra cualquier ventana abierta en esa carpeta y bórrala a mano." }
    if (-not $okData) { Write-Host "  No se pudo borrar del todo $Data. Reinicia el equipo y bórrala a mano." }
}
Write-Host ''
Read-Host '  Pulsa Enter para cerrar'
Remove-Item -LiteralPath $PSCommandPath -Force
