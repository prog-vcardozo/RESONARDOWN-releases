﻿# ResonarDown: aplica una versión nueva sobre la instalación existente.
# © 2026 VCARD26.
# Conserva la biblioteca, los ajustes, las descargas y el entorno de Python.
param(
    [string]$Source,
    [string]$AppDir = '',
    [int]$WaitPid = 0
)
$ErrorActionPreference = 'Continue'
$Host.UI.RawUI.WindowTitle = 'Actualizando ResonarDown'
Set-Location $env:TEMP
$Key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ResonarDown'

function Step([string]$t) { Write-Host "  $t" }
function Fail([string]$t) {
    Write-Host ''
    Write-Host "  $t" -ForegroundColor Red
    Write-Host ''
    Read-Host '  Pulsa Enter para cerrar'
    exit 1
}

Write-Host ''
Write-Host '  =========================================='
Write-Host '    Actualizando ResonarDown'
Write-Host '    © 2026 VCARD26'
Write-Host '  =========================================='
Write-Host ''

$Source = [IO.Path]::GetFullPath($Source).TrimEnd('\')
if (-not (Test-Path -LiteralPath (Join-Path $Source 'app.py'))) { Fail 'Este paquete no es una versión válida de ResonarDown.' }

if (-not $AppDir) {
    $reg = Get-ItemProperty -Path $Key -ErrorAction SilentlyContinue
    # Instalaciones con el nombre anterior (Resonar) quedaron registradas con otra clave.
    if (-not $reg) { $reg = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Resonar' -ErrorAction SilentlyContinue }
    if ($reg) { $AppDir = $reg.InstallLocation }
}
if (-not $AppDir -or -not (Test-Path -LiteralPath (Join-Path $AppDir 'app.py'))) {
    Fail 'No encontramos ResonarDown instalado en este equipo. Para instalarlo por primera vez, ejecuta Instalar.bat.'
}
$AppDir = [IO.Path]::GetFullPath($AppDir).TrimEnd('\')

$newVer = ''
$m = Select-String -LiteralPath (Join-Path $Source 'core\store.py') -Pattern 'APP_VERSION = "([^"]+)"' -ErrorAction SilentlyContinue
if ($m) { $newVer = $m.Matches[0].Groups[1].Value }
Step "Versión nueva: $newVer"
Step "Carpeta de ResonarDown: $AppDir"
Write-Host ''

# 1. Cerrar ResonarDown
Step 'Cerrando ResonarDown...'
if ($WaitPid -gt 0) { Wait-Process -Id $WaitPid -Timeout 20 -ErrorAction SilentlyContinue }
$webview = Join-Path $env:APPDATA 'ResonarDown\webview'
$webviewOld = Join-Path $env:APPDATA 'Resonar\webview'
Get-CimInstance Win32_Process | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and (
        $_.CommandLine -like "*$AppDir\*" -or $_.CommandLine -like "*$webview*" -or $_.CommandLine -like "*$webviewOld*")
} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1

# 2. Reemplazar los archivos de la aplicación (nunca toca .venv, bin ni tus datos)
if ($Source -ne $AppDir) {
    Step 'Copiando la versión nueva...'
    foreach ($d in @('core', 'ui', 'tools')) {
        robocopy (Join-Path $Source $d) (Join-Path $AppDir $d) /MIR /XD __pycache__ /R:3 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { Fail "No se pudieron copiar los archivos ($d). Cierra ResonarDown y vuelve a intentarlo." }
    }
    robocopy $Source $AppDir *.* /XF update.json /R:3 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
    # Lanzadores con el nombre anterior
    foreach ($f in @('Resonar.bat', 'Resonar en el navegador.bat')) { Remove-Item -LiteralPath (Join-Path $AppDir $f) -Force -ErrorAction SilentlyContinue }
    if ($LASTEXITCODE -ge 8) { Fail 'No se pudieron copiar los archivos. Cierra ResonarDown y vuelve a intentarlo.' }
    # update.json: manda el de la versión nueva (así se puede mudar el repositorio de versiones);
    # solo se conserva el anterior si la versión nueva no trae ninguno.
    $cfgNew = Join-Path $Source 'update.json'
    $cfgOld = Join-Path $AppDir 'update.json'
    $newRepo = ''
    try { $newRepo = (Get-Content -LiteralPath $cfgNew -Raw | ConvertFrom-Json).repo } catch { }
    if ($newRepo) { Copy-Item -LiteralPath $cfgNew -Destination $cfgOld -Force }
}

# 3. Componentes
$py = Join-Path $AppDir '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $py)) { Fail 'Falta el entorno de ResonarDown. Ejecuta Instalar.bat dentro de la carpeta de ResonarDown.' }
Step 'Actualizando componentes...'
& $py -m pip install --upgrade --disable-pip-version-check --no-cache-dir -q -r (Join-Path $AppDir 'requirements.txt')
if ($LASTEXITCODE -ne 0) { Step 'Aviso: no se pudieron actualizar algunos componentes; se usarán los que ya tenías.' }
& $py -c "import sys; sys.path.insert(0, r'$AppDir'); from core import engine; engine.ensure_ffmpeg()" | Out-Null
& $py -m compileall -q (Join-Path $AppDir 'core') (Join-Path $AppDir 'app.py') | Out-Null

# 4. Accesos directos y versión en Configuración > Aplicaciones
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $AppDir 'tools\instalar.ps1') -AppDir $AppDir | Out-Null

# 5. Volver a abrir ResonarDown
Write-Host ''
Step "Listo. ResonarDown $newVer está instalado."
Start-Process -FilePath (Join-Path $AppDir '.venv\Scripts\pythonw.exe') -ArgumentList 'app.py' -WorkingDirectory $AppDir
Start-Sleep -Seconds 3
