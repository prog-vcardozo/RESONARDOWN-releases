@echo off
rem ResonarDown. (c) 2026 VCARD26.
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Instalar ResonarDown
cd /d "%~dp0"
echo.
echo   ==========================================
echo     Instalando ResonarDown
echo     (c) 2026 VCARD26
echo   ==========================================
echo.
set "INSTALLED_PY=0"
set "INSTALLED_FF=0"

rem ---------- 1. Python ----------
set "PY="
for %%V in (3.12 3.11 3.13) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys;sys.exit(0 if (3,10)<=sys.version_info[:2]<=(3,13) else 1)" >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo [1/5] No hay una version compatible de Python. Instalando Python 3.12...
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    set "INSTALLED_PY=1"
  )
)
if not defined PY (
  echo.
  echo   No se pudo instalar Python automaticamente.
  echo   Descarga Python 3.12 desde https://www.python.org/downloads/
  echo   marca la casilla "Add python.exe to PATH" y vuelve a ejecutar Instalar.bat
  echo.
  pause
  exit /b 1
)
echo [1/5] Python listo:
%PY% --version

rem ---------- 2. Entorno propio de la aplicacion ----------
echo.
echo [2/5] Preparando el entorno de ResonarDown...
if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv
  if errorlevel 1 (
    echo   No se pudo crear el entorno. Revisa que Python este bien instalado.
    pause
    exit /b 1
  )
)
set "VPY=%~dp0.venv\Scripts\python.exe"
"%VPY%" -m pip install --upgrade pip --disable-pip-version-check --no-cache-dir -q

rem ---------- 3. Motor de descargas ----------
echo.
echo [3/5] Instalando el motor de descargas (puede tardar unos minutos)...
"%VPY%" -m pip install --upgrade --disable-pip-version-check --no-cache-dir -r requirements.txt
if errorlevel 1 (
  echo   No se pudo instalar el motor. Revisa tu conexion a internet y vuelve a intentarlo.
  pause
  exit /b 1
)
"%VPY%" -m pip install --upgrade --disable-pip-version-check --no-cache-dir -q pywebview
if errorlevel 1 (
  echo   Aviso: no se pudo instalar la ventana propia. ResonarDown se abrira en tu navegador.
)
rem Si el modulo de separacion ya estaba instalado, completa lo que le falte.
"%VPY%" -c "import audio_separator" >nul 2>&1
if not errorlevel 1 (
  "%VPY%" -m pip install --disable-pip-version-check --no-cache-dir -q audioread
)

rem ---------- 4. Conversion de audio ----------
rem ResonarDown usa el FFmpeg que viene incluido en su entorno: no instala otra copia en el sistema.
echo.
echo [4/5] Preparando la conversion de audio...
"%VPY%" -c "import sys;sys.path.insert(0,r'%~dp0.');from core import engine;sys.exit(0 if engine.ensure_ffmpeg() else 1)"
if errorlevel 1 (
  echo   No se pudo preparar FFmpeg. Vuelve a ejecutar Instalar.bat.
  pause
  exit /b 1
)
rem Deja el codigo de ResonarDown precompilado para que el primer inicio sea rapido.
"%VPY%" -m compileall -q "%~dp0core" "%~dp0app.py" >nul 2>&1
echo   Listo.

rem ---------- 5. Accesos directos y registro en Aplicaciones de Windows ----------
echo.
echo [5/5] Creando accesos directos y registrando ResonarDown en Windows...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\instalar.ps1" -AppDir "%~dp0." -InstalledPython %INSTALLED_PY% -InstalledFFmpeg %INSTALLED_FF%

echo.
echo   ==========================================
echo     ResonarDown quedo instalado.
echo     Abrelo con el icono "ResonarDown" del escritorio.
echo     Para quitarlo: Configuracion ^> Aplicaciones ^> ResonarDown
echo   ==========================================
echo.
start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0app.py"
timeout /t 6 >nul
exit /b 0
