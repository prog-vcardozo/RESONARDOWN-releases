"""Proceso aparte para separar voz e instrumental (uso: python -m core.stems in.wav carpeta modelo carpeta_modelos)."""
import json
import os
import sys


def main():
    src, out_dir, model, model_dir = sys.argv[1:5]
    print("STAGE Cargando el modelo (la primera vez se descarga)", flush=True)
    from audio_separator.separator import Separator
    sep = Separator(output_dir=out_dir, output_format="FLAC", model_file_dir=model_dir)
    sep.load_model(model_filename=model)
    print("STAGE Separando la voz (puede tardar unos minutos)", flush=True)
    files = sep.separate(src, {"Vocals": "vocals", "Instrumental": "instrumental"})
    found = {}
    for f in files:
        p = f if os.path.isabs(f) else os.path.join(out_dir, f)
        name = os.path.basename(p).lower()
        if name.startswith("vocals"):
            found["vocals"] = p
        elif name.startswith("instrumental"):
            found["instrumental"] = p
    if "vocals" not in found or "instrumental" not in found:
        print("No se generaron las dos pistas", flush=True)
        sys.exit(2)
    print("RESULT " + json.dumps(found), flush=True)


if __name__ == "__main__":
    main()
