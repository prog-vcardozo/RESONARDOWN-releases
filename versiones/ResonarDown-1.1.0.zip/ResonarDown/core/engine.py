"""Motor de ResonarDown: lectura de datos, descargas, etiquetas y separación de voz.
© 2026 VCARD26."""
import base64
import difflib
import html
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

import yt_dlp

from . import store

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/130.0 Safari/537.36")
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

PLATFORMS = [
    ("youtube", r"(youtube\.com|youtu\.be)"),
    ("spotify", r"(open\.spotify\.com|spotify\.link)"),
    ("tiktok", r"tiktok\.com"),
    ("instagram", r"instagram\.com"),
    ("soundcloud", r"soundcloud\.com"),
]
PLATFORM_NAMES = {"youtube": "YouTube", "spotify": "Spotify", "tiktok": "TikTok",
                  "instagram": "Instagram", "soundcloud": "SoundCloud", "otro": "Web"}


class UserError(Exception):
    """Error con un mensaje listo para mostrar al usuario."""


# --------------------------------------------------------------------------
# Herramientas externas
# --------------------------------------------------------------------------

BIN = Path(__file__).resolve().parent.parent / "bin"


def ensure_ffmpeg():
    """Usa el FFmpeg incluido en la app; lo deja como ffmpeg.exe para que todo lo encuentre."""
    dest = BIN / ("ffmpeg.exe" if sys.platform == "win32" else "ffmpeg")
    if dest.exists():
        return str(dest)
    try:
        import imageio_ffmpeg
        src = Path(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        return None
    BIN.mkdir(parents=True, exist_ok=True)
    try:
        os.link(src, dest)          # mismo archivo, sin ocupar espacio extra
    except Exception:
        shutil.copy2(src, dest)
    return str(dest)


def ffmpeg_path():
    return shutil.which("ffmpeg") or ensure_ffmpeg()


def total_ram_gb() -> float:
    try:
        if sys.platform == "win32":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return round(m.ullTotalPhys / 1024 ** 3, 1)
        return round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1024 ** 3, 1)
    except Exception:
        return 0.0


def ffprobe_available():
    f = ffmpeg_path()
    if not f:
        return False
    return bool(shutil.which("ffprobe") or (Path(f).parent / ("ffprobe.exe" if sys.platform == "win32" else "ffprobe")).exists())


def stems_available():
    return importlib.util.find_spec("audio_separator") is not None


def status():
    return {
        "ytdlp": yt_dlp.version.__version__,
        "ffmpeg": bool(ffmpeg_path()),
        "ffprobe": ffprobe_available(),
        "deno": bool(shutil.which("deno")),
        "stems": stems_available(),
        "ram_gb": total_ram_gb(),
    }


# --------------------------------------------------------------------------
# Utilidades de texto
# --------------------------------------------------------------------------

EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿⬀-⯿️‍⃣]")
NOISE = re.compile(
    r"\s*[\(\[](official( music)? (video|audio|visualizer|lyric video)|video oficial|audio oficial|"
    r"videoclip oficial|lyrics?( video)?|letra|con letra|hd|hq|4k|audio)[\)\]]", re.I)
VERSION_WORDS = ["live", "en vivo", "cover", "remix", "sped up", "slowed", "karaoke",
                 "instrumental", "8d", "nightcore", "reverb", "acustico", "acoustic"]


def clean_title(s: str) -> str:
    s = EMOJI.sub(" ", s or "")
    s = NOISE.sub("", s)
    s = re.sub(r"\s{2,}", " ", s).strip(" -|·•")
    return s.strip()


def clean_channel(s: str) -> str:
    s = re.sub(r"\s*-\s*Topic$", "", s or "", flags=re.I)
    s = re.sub(r"VEVO$", "", s).strip()
    return s


def split_artist(title: str, fallback: str):
    m = re.match(r"^(.+?)\s+[-–—]\s+(.+)$", title)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    return fallback, title


def safe_name(s: str) -> str:
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", s).strip().rstrip(".")
    return (s[:150] or "audio").strip()


def norm(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def http_get(url: str, timeout=20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "es,en;q=0.8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def detect(url: str) -> str:
    for key, pat in PLATFORMS:
        if re.search(pat, url, re.I):
            return key
    return "otro"


def friendly_error(e: Exception) -> str:
    if isinstance(e, UserError):
        return str(e)
    msg = str(e)
    low = msg.lower()
    if "sign in to confirm" in low or "not a bot" in low:
        return "YouTube pidió confirmar que no eres un robot. Actualiza el motor en Ajustes o activa “Usar la sesión del navegador”."
    if "private" in low:
        return "Este contenido es privado."
    if "login" in low or "log in" in low or "cookies" in low:
        return "Esta publicación requiere iniciar sesión. Activa “Usar la sesión del navegador” en Ajustes."
    if "not available in your country" in low or "geo" in low:
        return "Este contenido no está disponible en tu país."
    if "unsupported url" in low:
        return "No reconocemos este enlace. Revisa que sea de una canción, video o publicación."
    if "unable to download webpage" in low or "timed out" in low or "getaddrinfo" in low:
        return "No hay conexión con la plataforma. Revisa tu internet e inténtalo de nuevo."
    if "ffmpeg" in low:
        return "Falta ffmpeg. Ejecuta de nuevo Instalar.bat."
    return "No se pudo completar: " + re.sub(r"^ERROR:\s*(\[[^\]]+\]\s*)?", "", msg)[:220]


class _QuietLogger:
    def debug(self, m): pass
    def info(self, m): pass
    def warning(self, m): pass
    def error(self, m): pass


def base_opts() -> dict:
    o = {
        "quiet": True, "no_warnings": True, "noprogress": True, "logger": _QuietLogger(),
        "noplaylist": True, "socket_timeout": 25, "retries": 5, "fragment_retries": 5,
        "concurrent_fragment_downloads": 4, "windowsfilenames": True,
        "http_headers": {"User-Agent": UA}, "cachedir": str(store.DATA / "cache" / "yt-dlp"),
    }
    f = ffmpeg_path()
    if f:
        o["ffmpeg_location"] = f
    b = store.get_settings().get("cookies_browser")
    if b:
        o["cookiesfrombrowser"] = (b,)
    return o


# --------------------------------------------------------------------------
# Lectura de datos (vista previa)
# --------------------------------------------------------------------------

CODEC_NAMES = {"opus": "Opus", "mp4a": "AAC", "aac": "AAC", "mp3": "MP3", "vorbis": "Vorbis", "flac": "FLAC"}
CODEC_EXT = {"Opus": "opus", "AAC": "m4a", "MP3": "mp3", "Vorbis": "ogg", "FLAC": "flac"}


def _codec(acodec: str):
    a = (acodec or "").lower()
    for k, v in CODEC_NAMES.items():
        if a.startswith(k):
            return v
    return None


def _audio_options(info: dict):
    fmts = info.get("formats") or [info]
    only = [f for f in fmts if f.get("acodec") not in (None, "none") and f.get("vcodec") in (None, "none")]
    pool = only or [f for f in fmts if f.get("acodec") not in (None, "none")]
    best = {}
    for f in pool:
        c = _codec(f.get("acodec"))
        if not c:
            continue
        kbps = f.get("abr") or (f.get("tbr") if f in only else None)
        kbps = int(round(kbps)) if kbps else None
        prev = best.get(c)
        if prev is None or (kbps or 0) > (prev["kbps"] or 0):
            best[c] = {"id": f.get("format_id"), "codec": c, "kbps": kbps,
                       "ext": CODEC_EXT.get(c, "m4a"), "audio_only": f in only}
    opts = sorted(best.values(), key=lambda x: -(x["kbps"] or 0))
    # Opus y AAC a igual bitrate: Opus suena mejor, va primero.
    return opts[:3]


def _video_heights(info: dict):
    hs = sorted({f.get("height") for f in (info.get("formats") or [])
                 if f.get("vcodec") not in (None, "none") and f.get("height")}, reverse=True)
    wanted = [2160, 1440, 1080, 720, 480, 360]
    out = [h for h in wanted if any(x >= h * 0.95 for x in hs)]
    if not out and hs:
        out = [hs[0]]
    return out[:4]


def get_info(url: str, playlist: bool = False) -> dict:
    url = url.strip()
    if not re.match(r"^https?://", url, re.I):
        raise UserError("Pega un enlace completo que empiece con https://")
    platform = detect(url)
    if platform == "spotify":
        if re.search(r"/(playlist|album)/", url):
            return spotify_collection(url)
        return spotify_info(url)
    in_list = bool(re.search(r"[?&]list=", url))
    if playlist or (in_list and not re.search(r"[?&]v=|youtu\.be/", url)):
        return playlist_info(url, platform)
    try:
        with yt_dlp.YoutubeDL({**base_opts(), "skip_download": True}) as y:
            info = y.extract_info(url, download=False)
    except Exception as e:
        raise UserError(friendly_error(e))
    if info.get("_type") == "playlist":
        return playlist_info(url, platform)

    raw = info.get("title") or ""
    channel = clean_channel(info.get("uploader") or info.get("channel") or info.get("creator") or "")
    title = clean_title(info.get("track") or raw)
    artist = info.get("artist") or info.get("creator") if info.get("track") else None
    if not artist:
        artist, title = split_artist(title, channel)
    if platform == "soundcloud" and channel:
        title = re.sub(r"\s+by\s+" + re.escape(channel) + "$", "", title, flags=re.I)
    year = info.get("release_year") or (str(info.get("upload_date") or "")[:4] or None)
    audio = _audio_options(info)
    return {
        "type": "single", "platform": platform, "platform_name": PLATFORM_NAMES[platform],
        "url": info.get("webpage_url") or url,
        "title": title or "Sin título", "artist": artist or channel or "",
        "raw_title": raw, "channel": channel,
        "album": info.get("album") or "", "year": str(year) if year else "",
        "duration": int(info.get("duration") or 0),
        "thumbnail": info.get("thumbnail") or "",
        "audio": audio, "video": _video_heights(info),
        "playlist_hint": in_list,
    }


UNAVAILABLE = re.compile(r"^\[(private|deleted|unavailable)", re.I)


def _entry_from(e: dict, platform: str, n: int):
    raw = e.get("title") or e.get("track") or ""
    ch = clean_channel(e.get("channel") or e.get("uploader") or e.get("artist") or "")
    title = clean_title(e.get("track") or raw)
    artist = e.get("artist") if e.get("track") else None
    if not artist:
        artist, title = split_artist(title, ch)
    url = e.get("webpage_url") or e.get("url") or ""
    vid = e.get("id") or ""
    if platform == "youtube" and vid and not url.startswith("http"):
        url = "https://www.youtube.com/watch?v=" + vid
    thumb = e.get("thumbnail") or ""
    if not thumb and e.get("thumbnails"):
        thumb = (e["thumbnails"][-1] or {}).get("url", "")
    if platform == "youtube" and re.fullmatch(r"[\w-]{11}", vid or ""):
        thumb = f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
    ok = bool(url) and not UNAVAILABLE.match(raw)
    return {"n": n, "title": title or f"Pista {n}", "artist": artist or "", "duration": int(e.get("duration") or 0),
            "url": url, "thumbnail": thumb, "available": ok}


def playlist_info(url: str, platform: str) -> dict:
    opts = {**base_opts(), "skip_download": True, "noplaylist": False, "extract_flat": "in_playlist",
            "playlistend": 1000}
    try:
        with yt_dlp.YoutubeDL(opts) as y:
            info = y.extract_info(url, download=False)
    except Exception as e:
        raise UserError(friendly_error(e))
    entries = [e for e in (info.get("entries") or []) if e]
    # Algunas plataformas no dan títulos en la lectura rápida: se hace la lectura completa.
    if entries and sum(1 for e in entries if e.get("title")) < len(entries) / 2:
        try:
            with yt_dlp.YoutubeDL({**opts, "extract_flat": False, "playlistend": 300}) as y:
                info = y.extract_info(url, download=False)
            entries = [e for e in (info.get("entries") or []) if e]
        except Exception as e:
            raise UserError(friendly_error(e))
    if not entries:
        raise UserError("Esta lista está vacía o es privada.")
    items = [_entry_from(e, platform, i + 1) for i, e in enumerate(entries)]
    thumb = ""
    if info.get("thumbnails"):
        thumb = (info["thumbnails"][-1] or {}).get("url", "")
    thumb = thumb or next((i["thumbnail"] for i in items if i["thumbnail"]), "")
    return {
        "type": "playlist", "platform": platform, "platform_name": PLATFORM_NAMES[platform],
        "url": info.get("webpage_url") or url,
        "title": clean_title(info.get("title") or "Lista sin nombre"),
        "artist": clean_channel(info.get("uploader") or info.get("channel") or ""),
        "thumbnail": thumb, "count": len(items),
        "duration": sum(i["duration"] for i in items),
        "entries": items,
        "video": [1080, 720, 480, 360] if platform == "youtube" else [],
    }


def _spotify_next_data(kind: str, sid: str):
    page = http_get(f"https://open.spotify.com/embed/{kind}/{sid}").decode("utf-8", "replace")
    nd = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', page, re.S)
    return json.loads(nd.group(1)) if nd else None


def _find_collection(obj):
    stack = [obj]
    while stack:
        o = stack.pop()
        if isinstance(o, dict):
            if isinstance(o.get("trackList"), list) and o.get("trackList"):
                return o
            stack.extend(o.values())
        elif isinstance(o, list):
            stack.extend(o)
    return None


def spotify_collection(url: str) -> dict:
    m = re.search(r"/(playlist|album)/([A-Za-z0-9]+)", url)
    kind, sid = m.group(1), m.group(2)
    try:
        data = _spotify_next_data(kind, sid)
    except Exception as e:
        raise UserError(friendly_error(e))
    ent = _find_collection(data) if data else None
    if not ent:
        raise UserError("No se pudo leer esta lista de Spotify. Revisa que sea pública.")
    cover = _largest_image(ent)
    items = []
    for i, t in enumerate(ent["trackList"]):
        uri = t.get("uri") or ""
        tid = uri.split(":")[-1] if uri.startswith("spotify:track:") else ""
        items.append({"n": i + 1, "title": html.unescape(t.get("title") or f"Pista {i + 1}"),
                      "artist": html.unescape((t.get("subtitle") or "").replace("\u00a0", " ")),
                      "duration": int((t.get("duration") or 0) / 1000),
                      "url": f"https://open.spotify.com/track/{tid}" if tid else "",
                      "thumbnail": cover, "available": bool(tid) and t.get("isPlayable", True) is not False})
    name = ent.get("name") or ent.get("title") or "Lista de Spotify"
    return {
        "type": "playlist", "platform": "spotify", "platform_name": "Spotify", "url": url,
        "title": html.unescape(name), "artist": html.unescape(ent.get("subtitle") or ""),
        "thumbnail": cover, "count": len(items), "duration": sum(i["duration"] for i in items),
        "entries": items, "video": [], "collection_kind": kind,
    }


def _find_track_entity(obj):
    """Busca en el JSON de la página de Spotify el objeto de la canción."""
    stack = [obj]
    while stack:
        o = stack.pop()
        if isinstance(o, dict):
            if o.get("type") == "track" and o.get("name") and isinstance(o.get("artists"), list):
                return o
            stack.extend(o.values())
        elif isinstance(o, list):
            stack.extend(o)
    return None


def _largest_image(entity):
    urls = []
    def walk(o):
        if isinstance(o, dict):
            u = o.get("url")
            if isinstance(u, str) and "scdn.co/image" in u:
                urls.append((o.get("maxWidth") or o.get("width") or 0, u))
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(entity)
    return max(urls)[1] if urls else ""


def spotify_info(url: str, with_matches: bool = True) -> dict:
    if "spotify.link" in url:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            url = urllib.request.urlopen(req, timeout=15).geturl()
        except Exception:
            pass
    m = re.search(r"/track/([A-Za-z0-9]+)", url)
    if not m:
        raise UserError("Por ahora solo se pueden descargar canciones de Spotify (enlaces /track/), no álbumes ni listas.")
    tid = m.group(1)
    title = artist = album = cover = year = ""
    duration = 0
    try:
        page = http_get(f"https://open.spotify.com/embed/track/{tid}").decode("utf-8", "replace")
        nd = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', page, re.S)
        if nd:
            ent = _find_track_entity(json.loads(nd.group(1)))
            if ent:
                title = ent.get("name", "")
                artist = ", ".join(a.get("name", "") for a in ent["artists"] if a.get("name"))
                duration = int((ent.get("duration") or 0) / 1000)
                cover = _largest_image(ent)
                rd = ent.get("releaseDate")
                year = (rd.get("isoString", "") if isinstance(rd, dict) else str(rd or ""))[:4]
    except Exception:
        pass
    if not title:
        try:
            o = json.loads(http_get("https://open.spotify.com/oembed?url=" + urllib.parse.quote(url, safe="")))
            title = o.get("title", "")
            cover = cover or o.get("thumbnail_url", "")
        except Exception:
            pass
    if not title:
        raise UserError("No se pudieron leer los datos de Spotify. Revisa el enlace o tu conexión.")
    matches = find_matches(artist, title, duration) if with_matches else []
    return {
        "type": "single", "platform": "spotify", "platform_name": "Spotify", "url": url,
        "title": html.unescape(title), "artist": html.unescape(artist), "raw_title": "",
        "channel": "", "album": album, "year": year, "duration": duration,
        "thumbnail": cover, "matches": matches,
        "audio": [{"id": "bestaudio", "codec": "Opus", "kbps": 160, "ext": "opus", "audio_only": True}],
        "video": [],
    }


def find_matches(artist: str, title: str, duration: int):
    """Busca la canción en YouTube y puntúa cada resultado (0-99)."""
    query = f"{artist} - {title}" if artist else title
    opts = {**base_opts(), "skip_download": True, "extract_flat": "in_playlist"}
    try:
        with yt_dlp.YoutubeDL(opts) as y:
            res = y.extract_info(f"ytsearch8:{query} audio", download=False)
    except Exception as e:
        raise UserError(friendly_error(e))
    target = norm(f"{artist} {title}")
    want_version = [w for w in VERSION_WORDS if w in norm(title)]
    out = []
    for e in res.get("entries") or []:
        if not e:
            continue
        et, ch = e.get("title") or "", e.get("channel") or e.get("uploader") or ""
        cand = norm(f"{ch} {et}")
        score = difflib.SequenceMatcher(None, target, cand).ratio()
        if norm(title) and norm(title) in norm(et):
            score += 0.25
        if artist and norm(artist.split(",")[0]) in cand:
            score += 0.15
        if "topic" in ch.lower():
            score += 0.12
        for w in VERSION_WORDS:
            if w in norm(et) and w not in want_version:
                score -= 0.35
        d = int(e.get("duration") or 0)
        if duration and d:
            diff = abs(d - duration)
            score -= min(0.6, diff / 40.0) if diff > 3 else -0.08
        pct = max(1, min(99, int(round(score * 70))))
        url = e.get("url") or e.get("webpage_url") or ""
        if url and not url.startswith("http"):
            url = "https://www.youtube.com/watch?v=" + (e.get("id") or url)
        out.append({"title": et, "channel": clean_channel(ch), "duration": d, "url": url, "score": pct})
    out.sort(key=lambda x: -x["score"])
    return out[:4]


# --------------------------------------------------------------------------
# Carátulas y etiquetas
# --------------------------------------------------------------------------

def make_cover(src_url: str, dest: Path, square=True) -> bool:
    if not src_url:
        return False
    try:
        data = http_get(src_url)
    except Exception:
        return False
    raw = dest.with_suffix(".src")
    raw.write_bytes(data)
    f = ffmpeg_path()
    ok = False
    if f:
        vf = "crop='min(iw,ih)':'min(iw,ih)',scale=800:800:flags=lanczos" if square else "scale='min(1280,iw)':-2"
        r = subprocess.run([f, "-y", "-loglevel", "error", "-i", str(raw), "-vf", vf, "-q:v", "2", str(dest)],
                           capture_output=True, creationflags=NO_WINDOW)
        ok = r.returncode == 0 and dest.exists()
    if not ok and data[:3] == b"\xff\xd8\xff":
        dest.write_bytes(data)
        ok = True
    raw.unlink(missing_ok=True)
    return ok


def tag_file(path: Path, meta: dict, cover: Path = None):
    from mutagen import File as MFile
    ext = path.suffix.lower()
    pic = cover.read_bytes() if cover and cover.exists() else None
    title, artist = meta.get("title", ""), meta.get("artist", "")
    album, year = meta.get("album", ""), str(meta.get("year", "") or "")
    track = int(meta.get("track") or 0)
    try:
        if ext == ".mp3":
            from mutagen.id3 import ID3, TIT2, TPE1, TALB, TDRC, TRCK, APIC, ID3NoHeaderError
            try:
                t = ID3(path)
            except ID3NoHeaderError:
                t = ID3()
            t.delall("APIC")
            t.add(TIT2(encoding=3, text=title))
            if artist: t.add(TPE1(encoding=3, text=artist))
            if album: t.add(TALB(encoding=3, text=album))
            if year: t.add(TDRC(encoding=3, text=year))
            if track: t.add(TRCK(encoding=3, text=str(track)))
            if pic: t.add(APIC(encoding=3, mime="image/jpeg", type=3, desc="Cover", data=pic))
            t.save(path, v2_version=3)
        elif ext in (".m4a", ".mp4", ".m4v"):
            from mutagen.mp4 import MP4, MP4Cover
            t = MP4(path)
            t["\xa9nam"] = [title]
            if artist: t["\xa9ART"] = [artist]
            if album: t["\xa9alb"] = [album]
            if year: t["\xa9day"] = [year]
            if track: t["trkn"] = [(track, 0)]
            if pic: t["covr"] = [MP4Cover(pic, imageformat=MP4Cover.FORMAT_JPEG)]
            t.save()
        elif ext in (".opus", ".ogg", ".flac"):
            from mutagen.flac import Picture
            t = MFile(path)
            if t is None:
                return
            if t.tags is None:
                t.add_tags()
            t["title"] = title
            if artist: t["artist"] = artist
            if album: t["album"] = album
            if year: t["date"] = year
            if track: t["tracknumber"] = str(track)
            if pic:
                p = Picture()
                p.type, p.mime, p.data = 3, "image/jpeg", pic
                if ext == ".flac":
                    t.clear_pictures()
                    t.add_picture(p)
                else:
                    t["metadata_block_picture"] = [base64.b64encode(p.write()).decode("ascii")]
            t.save()
    except Exception:
        traceback.print_exc()


def quality_label(path: Path, codec_hint: str = "") -> str:
    try:
        from mutagen import File as MFile
        f = MFile(path)
        length = getattr(f.info, "length", 0) or 0
        kbps = getattr(f.info, "bitrate", 0) // 1000 if getattr(f.info, "bitrate", 0) else 0
        if not kbps and length:
            kbps = int(path.stat().st_size * 8 / length / 1000)
        names = {".opus": "Opus", ".m4a": "AAC", ".mp3": "MP3", ".ogg": "Vorbis", ".flac": "FLAC", ".wav": "WAV"}
        name = names.get(path.suffix.lower(), codec_hint or path.suffix[1:].upper())
        return f"{name} {kbps} kbps" if kbps else name
    except Exception:
        return codec_hint or path.suffix[1:].upper()


def unique_path(folder: Path, stem: str, ext: str) -> Path:
    p = folder / f"{stem}.{ext}"
    n = 2
    while p.exists():
        p = folder / f"{stem} ({n}).{ext}"
        n += 1
    return p


# --------------------------------------------------------------------------
# Cola de trabajos
# --------------------------------------------------------------------------

JOBS = {}
_jobs_lock = threading.Lock()


class _Limiter:
    """Cuántas descargas corren a la vez; se puede cambiar en Ajustes sin reiniciar."""

    def __init__(self):
        self._cv = threading.Condition()
        self._active = 0

    def limit(self):
        try:
            return max(1, min(4, int(store.get_settings().get("max_parallel", 2))))
        except Exception:
            return 2

    def __enter__(self):
        with self._cv:
            while self._active >= self.limit():
                self._cv.wait(timeout=1.0)
            self._active += 1

    def __exit__(self, *a):
        with self._cv:
            self._active -= 1
            self._cv.notify_all()


_slots = _Limiter()
_stems_lock = threading.Lock()   # la separación es pesada: de a una


class Cancelled(Exception):
    pass


def _new_job(kind, title, artist, platform, cover_url="", tag="", group=None):
    group = group or {}
    j = {"id": uuid.uuid4().hex[:12], "kind": kind, "title": title, "artist": artist,
         "platform": platform, "cover_url": cover_url, "tag": tag, "status": "queued",
         "progress": 0, "message": "En cola", "speed": "", "item_id": None, "error": "",
         "created": time.time(), "cancel": False, "group": group.get("id"),
         "group_title": group.get("title", ""), "group_cover": group.get("thumbnail", ""),
         "group_total": group.get("total", 0), "n": group.get("n", 0)}
    with _jobs_lock:
        JOBS[j["id"]] = j
    return j


def jobs_list():
    with _jobs_lock:
        js = sorted(JOBS.values(), key=lambda j: (-j["created"], j["n"]))
        return [dict(j) for j in js[:600]]


def cancel_jobs(ids=None, group=None):
    n = 0
    with _jobs_lock:
        for j in JOBS.values():
            if j["status"] in ("done", "error", "cancelled"):
                continue
            if (ids and j["id"] in ids) or (group and j["group"] == group):
                j["cancel"] = True
                if j["status"] == "queued":
                    j.update(status="cancelled", message="Cancelada")
                n += 1
    return {"cancelled": n}


def _upd(job, **kw):
    with _jobs_lock:
        job.update(kw)


def _human_speed(bps):
    if not bps:
        return ""
    return f"{bps / 1048576:.1f} MB/s".replace(".", ",")


def start_download(req: dict) -> dict:
    meta = req.get("meta") or {}
    mode = req.get("mode", "orig")
    fmt = str(req.get("fmt", ""))
    tag = req.get("label", "")
    job = _new_job("download", meta.get("title", ""), meta.get("artist", ""),
                   meta.get("platform", ""), meta.get("thumbnail", ""), tag, req.get("group"))
    if req.get("group"):
        job["created"] = req["group"].get("created", job["created"])
    threading.Thread(target=_run_download, args=(job, req), daemon=True).start()
    return job


def start_batch(reqs: list) -> dict:
    if not reqs:
        raise UserError("No hay canciones seleccionadas.")
    created = time.time()
    jobs = []
    for r in reqs:
        if r.get("group"):
            r["group"]["created"] = created
        jobs.append(start_download(r))
    return {"count": len(jobs), "group": (reqs[0].get("group") or {}).get("id")}


def _run_download(job, req):
    with _slots:
        if job["cancel"]:
            _upd(job, status="cancelled", message="Cancelada")
            return
        work = store.TMP / job["id"]
        work.mkdir(parents=True, exist_ok=True)
        try:
            _do_download(job, req, work)
        except Exception as e:
            if job["cancel"] or isinstance(e, Cancelled) or "Cancelled" in repr(e):
                _upd(job, status="cancelled", message="Cancelada", speed="")
            else:
                traceback.print_exc()
                _upd(job, status="error", message=friendly_error(e), error=str(e)[:400], speed="")
        finally:
            shutil.rmtree(work, ignore_errors=True)


def _do_download(job, req, work: Path):
    meta = req.get("meta") or {}
    mode = req.get("mode", "orig")
    fmt = str(req.get("fmt", ""))
    url = req.get("source_url") or req.get("url")
    if req.get("spotify_track"):
        # Canción de una lista de Spotify: datos de Spotify + mejor coincidencia en YouTube.
        _upd(job, status="downloading", message="Buscando la canción en YouTube")
        sp = spotify_info(req["spotify_track"])
        best = (sp.get("matches") or [None])[0]
        if not best or best["score"] < 55:
            raise UserError("No encontramos una coincidencia segura en YouTube para esta canción.")
        url = best["url"]
        meta = {**meta, "title": sp["title"] or meta.get("title"), "artist": sp["artist"] or meta.get("artist"),
                "year": sp.get("year") or meta.get("year", ""), "thumbnail": sp.get("thumbnail") or meta.get("thumbnail", ""),
                "duration": sp.get("duration") or meta.get("duration", 0)}
        _upd(job, title=meta["title"], artist=meta["artist"], cover_url=meta["thumbnail"])
    if not url:
        raise UserError("Falta el enlace.")
    if not ffmpeg_path():
        raise UserError("Falta ffmpeg. Ejecuta de nuevo Instalar.bat.")

    def hook(d):
        if job["cancel"]:
            raise Cancelled()
        if d.get("status") == "downloading":
            tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            got = d.get("downloaded_bytes") or 0
            pct = (got / tot * 85) if tot else min(80, job["progress"] + 1)
            _upd(job, status="downloading", progress=round(pct, 1),
                 message=f"Descargando {int(pct / 0.85)}%", speed=_human_speed(d.get("speed")))
        elif d.get("status") == "finished":
            _upd(job, progress=86, message="Procesando el audio", speed="")

    def pp_hook(d):
        if d.get("status") == "started":
            names = {"FFmpegExtractAudio": "Preparando el audio", "Merger": "Uniendo audio y video",
                     "FFmpegVideoConvertor": "Convirtiendo el video"}
            _upd(job, status="processing", progress=max(job["progress"], 88),
                 message=names.get(d.get("postprocessor"), "Procesando"))

    opts = {**base_opts(), "outtmpl": str(work / "%(id)s.%(ext)s"),
            "progress_hooks": [hook], "postprocessor_hooks": [pp_hook]}
    is_video = mode == "vid"
    if mode == "orig":
        sel = fmt if fmt and fmt not in ("bestaudio", "best") else ""
        opts["format"] = (sel + "/" if sel else "") + "bestaudio/best"
        opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "best"}]
    elif mode == "comp":
        codec, _, q = fmt.partition("-")
        codec = codec if codec in ("mp3", "m4a") else "mp3"
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": codec,
                                   "preferredquality": q or "320"}]
    else:
        h = int(fmt) if fmt.isdigit() else 1080
        opts["format"] = f"bv*[height<={h}]+ba/b[height<={h}]/bv*+ba/b"
        opts["format_sort"] = ["res", "vcodec:h264", "acodec:aac"]
        opts["merge_output_format"] = "mp4"

    _upd(job, status="downloading", message="Conectando")
    with yt_dlp.YoutubeDL(opts) as y:
        y.extract_info(url, download=True)

    files = [p for p in work.iterdir() if p.is_file() and p.suffix.lower() not in (".jpg", ".png", ".webp", ".part", ".ytdl", ".json")]
    if not files:
        raise UserError("La descarga terminó sin archivo. Inténtalo de nuevo.")
    out = max(files, key=lambda p: p.stat().st_size)

    _upd(job, status="processing", progress=94, message="Incrustando carátula y datos")
    item_id = uuid.uuid4().hex[:12]
    cover = store.COVERS / f"{item_id}.jpg"
    have_cover = make_cover(meta.get("thumbnail", ""), cover, square=not is_video)
    tag_file(out, meta, cover if have_cover else None)

    stem = safe_name(f"{meta.get('artist')} - {meta.get('title')}" if meta.get("artist") else meta.get("title") or out.stem)
    folder = store.download_dir()
    if req.get("subdir"):
        folder = folder / safe_name(req["subdir"])
        folder.mkdir(parents=True, exist_ok=True)
    if meta.get("track"):
        stem = f"{int(meta['track']):02d}. {stem}"
    dest = unique_path(folder, stem, out.suffix.lstrip(".").lower())
    shutil.move(str(out), dest)

    label = (req.get("label") or "MP4") if is_video else quality_label(dest)
    item = {"id": item_id, "title": meta.get("title", ""), "artist": meta.get("artist", ""),
            "album": meta.get("album", ""), "platform": meta.get("platform", ""),
            "path": str(dest), "tag": label, "kind": "video" if is_video else "audio",
            "cover": have_cover, "duration": meta.get("duration", 0), "date": time.time(),
            "source": req.get("url", "")}
    store.library_add(item)
    _upd(job, status="done", progress=100, message="Listo, con carátula y datos", item_id=item_id, tag=label)


# --------------------------------------------------------------------------
# Separación de voz (módulo opcional)
# --------------------------------------------------------------------------

STEM_MODELS = {
    "rapido": "UVR-MDX-NET-Inst_HQ_3.onnx",
    "calidad": "model_bs_roformer_ep_317_sdr_12.9755.ckpt",
}


def start_stems(item_id: str, which: str, quality: str = "rapido") -> dict:
    if quality == "calidad" and 0 < total_ram_gb() < 7.5:
        raise UserError("La máxima calidad necesita 8 GB de RAM. Usa la separación rápida.")
    item = store.library_get(item_id)
    if not item or not Path(item["path"]).exists():
        raise UserError("No se encontró el archivo en la biblioteca.")
    if not stems_available():
        raise UserError("El módulo de separación no está instalado. Instálalo desde Ajustes.")
    label = "Instrumental" if which == "instrumental" else "Voz"
    job = _new_job("stems", f"{item['title']} ({label})", item.get("artist", ""), item.get("platform", ""),
                   "", "FLAC")
    job["cover_item"] = item_id if item.get("cover") else None
    threading.Thread(target=_run_stems, args=(job, item, which, quality), daemon=True).start()
    return job


# Paquetes que el módulo de separación necesita y que a veces no se instalan solos.
STEM_EXTRA = ["audioread"]
MODULE_TO_PACKAGE = {"audioread": "audioread", "onnxruntime": "onnxruntime", "soundfile": "soundfile",
                     "samplerate": "samplerate", "resampy": "resampy", "pydub": "pydub", "librosa": "librosa",
                     "yaml": "pyyaml", "sklearn": "scikit-learn", "einops": "einops", "julius": "julius"}


def _pip_install(packages):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-cache-dir", "-q"] + packages
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       creationflags=NO_WINDOW)
    return r.returncode == 0


def _separate_once(job, wav: Path, work: Path, model: str):
    env = dict(os.environ)
    f = ffmpeg_path()
    if f:
        env["PATH"] = str(Path(f).parent) + os.pathsep + env.get("PATH", "")
    env["PYTHONIOENCODING"] = "utf-8"
    cmd = [sys.executable, "-m", "core.stems", str(wav), str(work), model, str(store.MODELS)]
    proc = subprocess.Popen(cmd, cwd=str(Path(__file__).resolve().parent.parent), env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
    result, tail = None, []
    start = time.time()
    for line in proc.stdout:
        line = line.strip()
        if line.startswith("RESULT "):
            result = json.loads(line[7:])
        elif line.startswith("STAGE "):
            _upd(job, message=line[6:])
        elif line:
            tail = (tail + [line])[-12:]
        m = re.search(r"(\d{1,3})%\|", line)
        if m:
            _upd(job, progress=min(95, 15 + int(m.group(1)) * 0.8))
        elif time.time() - start > 2:
            _upd(job, progress=min(90, job["progress"] + 0.2))
    proc.wait()
    return proc.returncode, result, tail


def _run_stems(job, item, which, quality):
    _upd(job, message="En cola, se separa una canción a la vez")
    with _stems_lock:
        _run_stems_now(job, item, which, quality)


def _run_stems_now(job, item, which, quality):
    work = store.TMP / job["id"]
    work.mkdir(parents=True, exist_ok=True)
    try:
        src = Path(item["path"])
        _upd(job, status="processing", progress=5, message="Preparando el audio")
        wav = work / "input.wav"
        r = subprocess.run([ffmpeg_path(), "-y", "-loglevel", "error", "-i", str(src), "-vn",
                            "-ar", "44100", "-ac", "2", str(wav)], capture_output=True, creationflags=NO_WINDOW)
        if r.returncode != 0:
            raise UserError("No se pudo leer el archivo de audio.")
        model = STEM_MODELS.get(quality, STEM_MODELS["rapido"])
        _upd(job, progress=12, message="Cargando el modelo")
        repaired = set()
        for _ in range(4):
            rc, result, tail = _separate_once(job, wav, work, model)
            if rc == 0 and result:
                break
            missing = None
            for line in tail:
                m = re.search(r"No module named '([\w\.]+)'", line)
                if m:
                    missing = m.group(1).split(".")[0]
            if not missing or missing in repaired:
                detail = next((l for l in reversed(tail) if "Error" in l), tail[-1] if tail else "")
                raise UserError("La separación falló. " + detail[-180:])
            repaired.add(missing)
            _upd(job, progress=12, message=f"Reparando el módulo (instalando {missing})")
            if not _pip_install([MODULE_TO_PACKAGE.get(missing, missing)]):
                raise UserError(f"Falta el componente {missing} y no se pudo instalar. Revisa tu conexión.")
            _upd(job, message="Reintentando la separación")
        else:
            raise UserError("La separación falló después de reparar el módulo.")
        key = "instrumental" if which == "instrumental" else "vocals"
        out = Path(result[key])
        label = "Instrumental" if which == "instrumental" else "Voz"
        stem = safe_name(f"{item.get('artist')} - {item['title']} ({label})" if item.get("artist") else f"{item['title']} ({label})")
        dest = unique_path(store.download_dir(), stem, "flac")
        shutil.move(str(out), dest)
        new_id = uuid.uuid4().hex[:12]
        cover = None
        if item.get("cover"):
            c = store.COVERS / f"{item['id']}.jpg"
            if c.exists():
                cover = store.COVERS / f"{new_id}.jpg"
                shutil.copy(c, cover)
        tag_file(dest, {"title": f"{item['title']} ({label})", "artist": item.get("artist", ""),
                        "album": item.get("album", "")}, cover)
        store.library_add({"id": new_id, "title": f"{item['title']} ({label})", "artist": item.get("artist", ""),
                           "album": item.get("album", ""), "platform": item.get("platform", ""), "path": str(dest),
                           "tag": "FLAC " + label.lower(), "kind": "audio", "cover": bool(cover),
                           "duration": item.get("duration", 0), "date": time.time(), "source": item.get("source", "")})
        _upd(job, status="done", progress=100, message="Listo", item_id=new_id)
    except Exception as e:
        traceback.print_exc()
        _upd(job, status="error", message=friendly_error(e))
    finally:
        shutil.rmtree(work, ignore_errors=True)


# --------------------------------------------------------------------------
# Mantenimiento: actualizar motor e instalar módulo
# --------------------------------------------------------------------------

def _pip_job(title, packages):
    job = _new_job("setup", title, "", "")

    def run():
        _upd(job, status="processing", progress=10, message="Descargando paquetes")
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "--disable-pip-version-check", "--no-cache-dir"] + packages
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                             encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        tail = []
        for line in p.stdout:
            tail = (tail + [line.strip()])[-6:]
            if line.startswith("Collecting") or line.startswith("Downloading"):
                _upd(job, progress=min(85, job["progress"] + 3), message=line.strip()[:90])
        p.wait()
        if p.returncode == 0:
            _upd(job, status="done", progress=100, message="Instalado. Reinicia ResonarDown para usarlo.")
        else:
            _upd(job, status="error", message="No se pudo instalar: " + " ".join(tail)[-200:])

    threading.Thread(target=run, daemon=True).start()
    return job


def update_engine():
    return _pip_job("Actualizar motor de descargas", ["yt-dlp[default]", "deno"])


def install_stems():
    return _pip_job("Módulo de separación de voz", ["audio-separator[cpu]"] + STEM_EXTRA)
