@echo off
rem Resonar. (c) 2026 VCARD26.
rem Actualiza tu Resonar instalado con los archivos de esta carpeta.
rem Uso: descomprime la version nueva en cualquier carpeta y haz doble clic aqui.
chcp 65001 >nul
title Actualizar Resonar
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\actualizar.ps1" -Source "%~dp0."
