@echo off
chcp 65001 >nul
title Resonar (modo navegador)
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Primero ejecuta Instalar.bat
  pause
  exit /b 1
)
echo Abriendo Resonar en tu navegador. Deja esta ventana abierta mientras lo usas.
echo Si algo falla, el detalle del error aparece aqui.
echo.
"%~dp0.venv\Scripts\python.exe" "%~dp0app.py" --browser
pause
