"""Ajustes y biblioteca guardados en disco (carpeta de datos del usuario).
© 2026 VCARD26."""
import json
import os
import sys
import threading
from pathlib import Path

APP_NAME = "Resonar"
APP_VERSION = "1.0.0"
COPYRIGHT = "© 2026 VCARD26"


def _data_dir() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    d = base / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


DATA = _data_dir()
COVERS = DATA / "covers"
TMP = DATA / "tmp"
MODELS = DATA / "models"
for _d in (COVERS, TMP, MODELS):
    _d.mkdir(parents=True, exist_ok=True)

_lock = threading.RLock()
_SETTINGS_FILE = DATA / "settings.json"
_LIBRARY_FILE = DATA / "library.json"


def _default_download_dir() -> str:
    music = Path.home() / "Music"
    if not music.exists():
        music = Path.home()
    return str(music / APP_NAME)


DEFAULTS = {
    "download_dir": _default_download_dir(),
    "cookies_browser": "",  # "", "firefox", "edge", "chrome"
    "max_parallel": 2,
}


def _read(path: Path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return fallback


def _write(path: Path, data):
    tmp = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def get_settings() -> dict:
    with _lock:
        s = dict(DEFAULTS)
        s.update(_read(_SETTINGS_FILE, {}))
        return s


def update_settings(changes: dict) -> dict:
    with _lock:
        s = get_settings()
        for k in DEFAULTS:
            if k in changes:
                s[k] = changes[k]
        _write(_SETTINGS_FILE, s)
        return s


def download_dir() -> Path:
    d = Path(get_settings()["download_dir"]).expanduser()
    d.mkdir(parents=True, exist_ok=True)
    return d


def library() -> list:
    """Biblioteca con tamaño y formato de cada archivo; oculta los que ya no existen."""
    with _lock:
        items = _read(_LIBRARY_FILE, [])
    out = []
    for i in items:
        p = Path(i.get("path", ""))
        try:
            st = p.stat()
        except OSError:
            continue
        i = dict(i)
        i["size"] = st.st_size
        i["ext"] = p.suffix.lower().lstrip(".")
        i.setdefault("date", st.st_mtime)
        out.append(i)
    return out


def library_get(item_id: str):
    for i in _read(_LIBRARY_FILE, []):
        if i.get("id") == item_id:
            return i
    return None


def library_add(item: dict):
    with _lock:
        items = _read(_LIBRARY_FILE, [])
        items.insert(0, item)
        _write(_LIBRARY_FILE, items)


def library_remove(item_id: str):
    with _lock:
        items = [i for i in _read(_LIBRARY_FILE, []) if i.get("id") != item_id]
        _write(_LIBRARY_FILE, items)
