"""Actualizaciones de Resonar desde las versiones publicadas en GitHub.
© 2026 VCARD26.

Cada versión se publica en el repositorio público como un archivo latest.json
(versión, novedades, huella sha256) junto al zip. También acepta un "Release" de GitHub.
El repositorio se configura en update.json: {"repo": "usuario/repositorio"}.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

from . import store

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "update.json"
API = os.environ.get("RESONAR_UPDATE_API", "https://api.github.com").rstrip("/")
RAW = os.environ.get("RESONAR_UPDATE_RAW", "https://raw.githubusercontent.com").rstrip("/")
CHECK_EVERY = 6 * 3600
NEW_CONSOLE = 0x00000010 if sys.platform == "win32" else 0

_cache = {"time": 0.0, "result": None}
_lock = threading.Lock()
_applying = threading.Event()


def repo() -> str:
    try:
        r = json.loads(CONFIG.read_text(encoding="utf-8")).get("repo", "").strip()
    except Exception:
        return ""
    return r if re.fullmatch(r"[\w.-]+/[\w.-]+", r) else ""


def vtuple(v: str):
    nums = [int(n) for n in re.findall(r"\d+", v or "")[:3]]
    return tuple(nums + [0] * (3 - len(nums)))


def _get(url: str, timeout=15):
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json",
                                               "User-Agent": f"Resonar/{store.APP_VERSION}"})
    return urllib.request.urlopen(req, timeout=timeout)


def _from_manifest(r: str):
    """Versión publicada como archivo latest.json en el repositorio (método principal)."""
    base = f"{RAW}/{r}/main"
    with _get(f"{base}/latest.json?t={int(time.time() // 300)}", timeout=10) as resp:
        m = json.loads(resp.read().decode("utf-8"))
    latest = str(m.get("version", "")).lstrip("vV")
    url = m.get("url") or ""
    if url and not url.startswith("http"):
        url = f"{base}/{url.lstrip('/')}"
    sha = str(m.get("sha256") or "").lower()
    return {
        "latest": latest, "url": url, "size": int(m.get("size") or 0),
        "notes": str(m.get("notes") or "").strip()[:4000],
        "published": str(m.get("published") or "")[:10],
        "digest": f"sha256:{sha}" if sha else "",
        "page": f"https://github.com/{r}",
    }


def _from_release(r: str):
    """Versión publicada como Release de GitHub (método alternativo, por si se publica a mano)."""
    with _get(f"{API}/repos/{r}/releases/latest", timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    asset = next((a for a in data.get("assets") or [] if a.get("name", "").lower().endswith(".zip")), None)
    return {
        "latest": (data.get("tag_name") or "").lstrip("vV"),
        "url": asset.get("browser_download_url", "") if asset else "",
        "size": int(asset.get("size") or 0) if asset else 0,
        "notes": (data.get("body") or "").strip()[:4000],
        "published": (data.get("published_at") or "")[:10],
        "digest": (asset.get("digest") or "") if asset else "",
        "page": data.get("html_url", ""),
    }


def check(force: bool = False) -> dict:
    r = repo()
    if not r:
        return {"configured": False, "current": store.APP_VERSION}
    with _lock:
        if not force and _cache["result"] and time.time() - _cache["time"] < CHECK_EVERY:
            return _cache["result"]
    found, not_found, offline = [], 0, 0
    for source in (_from_manifest, _from_release):
        try:
            info = source(r)
            if info.get("latest") and info.get("url"):
                found.append(info)
        except urllib.error.HTTPError as e:
            not_found += e.code == 404
        except Exception:
            offline += 1
    if not found:
        if offline and not not_found:
            msg = "No se pudo comprobar. Revisa tu conexión a internet."
        else:
            msg = "Todavía no hay versiones publicadas."
        return {"configured": True, "current": store.APP_VERSION, "error": msg}
    best = max(found, key=lambda i: vtuple(i["latest"]))
    result = {"configured": True, "current": store.APP_VERSION, **best,
              "available": vtuple(best["latest"]) > vtuple(store.APP_VERSION)}
    with _lock:
        _cache.update(time=time.time(), result=result)
    return result


def _find_package(folder: Path) -> Path:
    for cand in [folder] + [p for p in folder.iterdir() if p.is_dir()]:
        if (cand / "app.py").exists() and (cand / "core" / "engine.py").exists() and (cand / "tools" / "actualizar.ps1").exists():
            return cand
    raise RuntimeError("El paquete descargado no es una versión válida de Resonar.")


def _safe_extract(zf: zipfile.ZipFile, dest: Path):
    root = dest.resolve()
    for m in zf.infolist():
        target = (dest / m.filename).resolve()
        if root != target and root not in target.parents:
            raise RuntimeError("El paquete descargado tiene rutas no válidas.")
    zf.extractall(dest)


def apply(on_exit) -> dict:
    """Descarga la versión nueva, la verifica y lanza el actualizador. Luego cierra Resonar."""
    from . import engine
    if sys.platform != "win32" and not os.environ.get("RESONAR_UPDATE_TEST"):
        raise engine.UserError("La actualización automática está disponible en Windows.")
    if _applying.is_set():
        raise engine.UserError("La actualización ya está en curso.")
    info = check(force=True)
    if info.get("error"):
        raise engine.UserError(info["error"])
    if not info.get("available"):
        raise engine.UserError("Ya tienes la última versión.")
    _applying.set()
    job = engine._new_job("update", f"Actualización a Resonar {info['latest']}", "", "", "", "")

    def run():
        work = store.TMP / "update"
        try:
            shutil.rmtree(work, ignore_errors=True)
            work.mkdir(parents=True, exist_ok=True)
            pkg = work / "resonar.zip"
            engine._upd(job, status="downloading", message="Descargando la actualización")
            h = hashlib.sha256()
            with _get(info["url"], timeout=30) as resp, open(pkg, "wb") as out:
                total = int(resp.headers.get("Content-Length") or info.get("size") or 0)
                got = 0
                while True:
                    chunk = resp.read(262144)
                    if not chunk:
                        break
                    out.write(chunk)
                    h.update(chunk)
                    got += len(chunk)
                    if total:
                        engine._upd(job, progress=round(got / total * 80, 1),
                                    message=f"Descargando la actualización {int(got / total * 100)}%")
            digest = info.get("digest", "")
            if digest.startswith("sha256:") and digest[7:].lower() != h.hexdigest():
                raise RuntimeError("La descarga llegó dañada. Inténtalo de nuevo.")
            engine._upd(job, status="processing", progress=85, message="Verificando el paquete")
            with zipfile.ZipFile(pkg) as zf:
                _safe_extract(zf, work / "x")
            src = _find_package(work / "x")
            engine._upd(job, progress=95, message="Resonar se cerrará y volverá a abrirse actualizado")
            script = src / "tools" / "actualizar.ps1"
            cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script),
                   "-Source", str(src), "-AppDir", str(ROOT), "-WaitPid", str(os.getpid())]
            if os.environ.get("RESONAR_UPDATE_TEST"):
                engine._upd(job, status="done", progress=100, message="Listo para actualizar (prueba)",
                            error=json.dumps({"cmd": cmd}))
                return
            subprocess.Popen(cmd, cwd=os.environ.get("TEMP", str(work)), creationflags=NEW_CONSOLE)
            engine._upd(job, status="done", progress=100, message="Actualizando… Resonar volverá a abrirse")
            threading.Timer(1.5, on_exit).start()
        except Exception as e:
            _applying.clear()
            engine._upd(job, status="error", message=str(e) if isinstance(e, RuntimeError) else engine.friendly_error(e))

    threading.Thread(target=run, daemon=True).start()
    return {"ok": True, "job": job["id"], "version": info["latest"]}


def clean_leftovers():
    """Borra archivos temporales de sesiones anteriores (incluida una actualización ya aplicada)."""
    try:
        for p in store.TMP.iterdir():
            shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)
    except Exception:
        pass
